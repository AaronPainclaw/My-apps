#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
zig_bin="${ZIG_BIN:-zig}"
build_dir="$project_dir/build"
dist_dir="$project_dir/dist"

mkdir -p "$build_dir" "$dist_dir"

if [[ ! -f "$project_dir/assets/mechanicus.ico" ]]; then
  if ! command -v convert >/dev/null 2>&1; then
    echo "assets/mechanicus.ico is missing and ImageMagick 'convert' is unavailable." >&2
    exit 1
  fi
  convert \
    -background none \
    "$project_dir/assets/mechanicus_emblem.svg" \
    -define icon:auto-resize=256,128,64,48,32,24,16 \
    "$project_dir/assets/mechanicus.ico"
fi

export ZIG_LOCAL_CACHE_DIR="${ZIG_LOCAL_CACHE_DIR:-/tmp/pocketmagos-zig-local}"
export ZIG_GLOBAL_CACHE_DIR="${ZIG_GLOBAL_CACHE_DIR:-/tmp/pocketmagos-zig-global}"

(
  cd "$project_dir/src"
  "$zig_bin" rc \
    /nologo \
    /I . \
    "/fo$build_dir/PocketMagos_v4.res" \
    app.rc
)

"$zig_bin" c++ \
  -target x86_64-windows-gnu \
  -std=c++20 \
  -Os \
  -Wall \
  -Wextra \
  -Wpedantic \
  -Werror \
  -fstack-protector-strong \
  -DUNICODE \
  -D_UNICODE \
  -municode \
  -Wl,/subsystem:windows \
  "$project_dir/src/main.cpp" \
  "$project_dir/src/audio_engine.cpp" \
  "$build_dir/PocketMagos_v4.res" \
  -o "$dist_dir/PocketMagos_v4.exe" \
  -lole32 \
  -loleaut32 \
  -luuid \
  -lsapi \
  -lwinmm \
  -lcomctl32 \
  -lcomdlg32 \
  -ldwmapi \
  -ladvapi32 \
  -lgdi32 \
  -luser32 \
  -lkernel32

rm -f "$dist_dir/main.lib"
echo "Built: $dist_dir/PocketMagos_v4.exe"
