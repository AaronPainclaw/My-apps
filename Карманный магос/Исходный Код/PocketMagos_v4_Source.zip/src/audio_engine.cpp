#define WIN32_LEAN_AND_MEAN
#include "audio_engine.h"

#include <sapi.h>
#include <sphelper.h>
#include <mmsystem.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cwctype>
#include <exception>
#include <limits>
#include <memory>
#include <new>

namespace {

constexpr int kSampleRate = 22050;
constexpr double kPi = 3.1415926535897932384626433832795;
constexpr size_t kSpeechChunkCharacters = 700;
constexpr ULONGLONG kMaxRenderedSpeechBytes = 24ULL * 1024ULL * 1024ULL;
constexpr unsigned kWaveErrorBase = 0x2200;
constexpr GUID kWaveFormatExGuid = {
    0xC31ADBAE,
    0x527F,
    0x4FF5,
    {0xA2, 0x30, 0xF6, 0x2B, 0xB6, 0x1F, 0xF7, 0x0C}};

template <typename T>
void SafeRelease(T*& value) {
    if (value) {
        value->Release();
        value = nullptr;
    }
}

HRESULT CancellationResult() {
    return HRESULT_FROM_WIN32(ERROR_CANCELLED);
}

HRESULT LitanyTooLongResult() {
    return HRESULT_FROM_WIN32(ERROR_FILE_TOO_LARGE);
}

HRESULT WaveResultToHresult(MMRESULT result) {
    if (result == MMSYSERR_NOERROR) {
        return S_OK;
    }
    return MAKE_HRESULT(
        SEVERITY_ERROR,
        FACILITY_ITF,
        kWaveErrorBase + (result & 0x00FFu));
}

bool TryGetWaveResult(HRESULT result, MMRESULT& waveResult) {
    if (HRESULT_FACILITY(result) != FACILITY_ITF) {
        return false;
    }
    const unsigned code = HRESULT_CODE(result);
    if (code < kWaveErrorBase || code > kWaveErrorBase + 0x00FFu) {
        return false;
    }
    waveResult = static_cast<MMRESULT>(code - kWaveErrorBase);
    return true;
}

size_t FindSpeechChunkEnd(const std::wstring& text, size_t start) {
    const size_t hardEnd =
        std::min(text.size(), start + kSpeechChunkCharacters);
    if (hardEnd >= text.size()) {
        return text.size();
    }

    const size_t preferredStart =
        std::min(hardEnd, start + kSpeechChunkCharacters / 2);
    for (size_t cursor = hardEnd; cursor > preferredStart; --cursor) {
        const wchar_t character = text[cursor - 1];
        if (character == L'.' || character == L'!' ||
            character == L'?' || character == L';' ||
            character == L':' || character == L'\n') {
            return cursor;
        }
    }
    for (size_t cursor = hardEnd; cursor > preferredStart; --cursor) {
        if (iswspace(text[cursor - 1])) {
            return cursor;
        }
    }

    size_t result = hardEnd;
    if (result < text.size() &&
        result > start &&
        text[result - 1] >= 0xD800 &&
        text[result - 1] <= 0xDBFF &&
        text[result] >= 0xDC00 &&
        text[result] <= 0xDFFF) {
        --result;
    }
    return result > start ? result : hardEnd;
}

std::wstring EscapeSapiXmlText(const std::wstring& text) {
    std::wstring escaped;
    escaped.reserve(text.size() + text.size() / 8);
    for (size_t index = 0; index < text.size(); ++index) {
        const wchar_t character = text[index];
        if (character >= 0xD800 && character <= 0xDBFF) {
            if (index + 1 < text.size() &&
                text[index + 1] >= 0xDC00 &&
                text[index + 1] <= 0xDFFF) {
                escaped.push_back(character);
                escaped.push_back(text[++index]);
            } else {
                escaped.push_back(static_cast<wchar_t>(0xFFFD));
            }
            continue;
        }
        if (character >= 0xDC00 && character <= 0xDFFF) {
            escaped.push_back(static_cast<wchar_t>(0xFFFD));
            continue;
        }
        switch (character) {
            case L'&':
                escaped.append(L"&amp;");
                break;
            case L'<':
                escaped.append(L"&lt;");
                break;
            case L'>':
                escaped.append(L"&gt;");
                break;
            case L'\"':
                escaped.append(L"&quot;");
                break;
            case L'\'':
                escaped.append(L"&apos;");
                break;
            default:
                // XML 1.0 permits tab, line feed and carriage return, but not
                // the remaining C0 control characters. Replacing an invalid
                // control with a space keeps arbitrary editor text speakable.
                escaped.push_back(
                    character < 0x20 &&
                            character != L'\t' &&
                            character != L'\n' &&
                            character != L'\r'
                        ? L' '
                        : character);
                break;
        }
    }
    return escaped;
}

std::wstring BuildTimbreMarkup(
    const std::wstring& text,
    int voiceTimbre) {
    const int timbre = std::clamp(voiceTimbre, -10, 10);
    std::wstring markup = L"<pitch absmiddle=\"";
    markup.append(std::to_wstring(timbre));
    markup.append(L"\">");
    markup.append(EscapeSapiXmlText(text));
    markup.append(L"</pitch>");
    return markup;
}

HRESULT WaitForSpeechChunk(
    ISpVoice* voice,
    std::atomic<bool>& stopRequested) {
    while (true) {
        const HRESULT waitResult = voice->WaitUntilDone(75);
        if (waitResult == S_OK) {
            return S_OK;
        }
        if (waitResult != S_FALSE) {
            return waitResult;
        }
        if (stopRequested.load()) {
            voice->Speak(nullptr, SPF_PURGEBEFORESPEAK, nullptr);
            return CancellationResult();
        }
    }
}

HRESULT CheckRenderedSpeechSize(IStream* stream) {
    STATSTG statistics = {};
    const HRESULT result = stream->Stat(&statistics, STATFLAG_NONAME);
    if (FAILED(result)) {
        return result;
    }
    if (statistics.cbSize.QuadPart < 0 ||
        static_cast<ULONGLONG>(statistics.cbSize.QuadPart) >
            kMaxRenderedSpeechBytes) {
        return LitanyTooLongResult();
    }
    return S_OK;
}

std::wstring ReadTokenString(ISpObjectToken* token, const wchar_t* name) {
    if (!token) {
        return {};
    }
    wchar_t* value = nullptr;
    if (FAILED(token->GetStringValue(name, &value)) || !value) {
        return {};
    }
    std::wstring result(value);
    CoTaskMemFree(value);
    return result;
}

std::wstring ReadTokenId(ISpObjectToken* token) {
    if (!token) {
        return {};
    }
    wchar_t* value = nullptr;
    if (FAILED(token->GetId(&value)) || !value) {
        return {};
    }
    std::wstring result(value);
    CoTaskMemFree(value);
    return result;
}

std::wstring DescribeLanguage(const std::wstring& languageValue) {
    if (languageValue.empty()) {
        return L"язык не указан";
    }

    const size_t separator = languageValue.find(L';');
    const std::wstring firstLanguage = languageValue.substr(0, separator);
    wchar_t* end = nullptr;
    const unsigned long languageId = wcstoul(firstLanguage.c_str(), &end, 16);
    if (!end || end == firstLanguage.c_str()) {
        return languageValue;
    }

    wchar_t localizedName[128] = {};
    const LCID localeId = MAKELCID(static_cast<LANGID>(languageId), SORT_DEFAULT);
    if (GetLocaleInfoW(
            localeId,
            LOCALE_SLOCALIZEDDISPLAYNAME,
            localizedName,
            static_cast<int>(std::size(localizedName))) > 0) {
        return localizedName;
    }

    wchar_t fallback[16] = {};
    swprintf_s(fallback, L"0x%04lX", languageId);
    return fallback;
}

HRESULT ApplyVoiceToken(ISpVoice* voice, const std::wstring& tokenId) {
    if (!voice || tokenId.empty()) {
        return S_OK;
    }

    ISpObjectToken* token = nullptr;
    HRESULT result = CoCreateInstance(
        CLSID_SpObjectToken,
        nullptr,
        CLSCTX_INPROC_SERVER,
        __uuidof(ISpObjectToken),
        reinterpret_cast<void**>(&token));
    if (SUCCEEDED(result)) {
        result = token->SetId(nullptr, tokenId.c_str(), FALSE);
    }
    if (SUCCEEDED(result)) {
        result = voice->SetVoice(token);
    }
    SafeRelease(token);
    return result;
}

HRESULT RenderSpeechToMemory(
    const RitualRequest& request,
    std::atomic<bool>& stopRequested,
    std::vector<float>& samples,
    const RitualStatusCallback& statusCallback) {
    ISpVoice* voice = nullptr;
    ISpStream* speechStream = nullptr;
    IStream* memoryStream = nullptr;

    HRESULT result = CoCreateInstance(
        CLSID_SpVoice,
        nullptr,
        CLSCTX_ALL,
        __uuidof(ISpVoice),
        reinterpret_cast<void**>(&voice));
    if (FAILED(result)) {
        return result;
    }

    // A voice can be removed or damaged after the list was populated. SAPI
    // creates the object with the current Windows default voice, so a failed
    // explicit token selection safely falls back to that voice.
    const HRESULT voiceResult =
        ApplyVoiceToken(voice, request.voiceTokenId);
    if (FAILED(voiceResult) &&
        !request.voiceTokenId.empty() &&
        statusCallback) {
        statusCallback(RitualStage::VoiceFallback);
    }

    result = voice->SetRate(
        std::clamp(request.settings.speechRate, -10, 10));
    if (SUCCEEDED(result)) {
        result = voice->SetVolume(100);
    }

    if (SUCCEEDED(result)) {
        result = CreateStreamOnHGlobal(nullptr, TRUE, &memoryStream);
    }
    if (SUCCEEDED(result)) {
        result = CoCreateInstance(
            CLSID_SpStream,
            nullptr,
            CLSCTX_INPROC_SERVER,
            __uuidof(ISpStream),
            reinterpret_cast<void**>(&speechStream));
    }

    WAVEFORMATEX waveFormat = {};
    waveFormat.wFormatTag = WAVE_FORMAT_PCM;
    waveFormat.nChannels = 1;
    waveFormat.nSamplesPerSec = kSampleRate;
    waveFormat.wBitsPerSample = 16;
    waveFormat.nBlockAlign =
        static_cast<WORD>(waveFormat.nChannels * waveFormat.wBitsPerSample / 8);
    waveFormat.nAvgBytesPerSec = waveFormat.nSamplesPerSec * waveFormat.nBlockAlign;

    if (SUCCEEDED(result)) {
        result = speechStream->SetBaseStream(
            memoryStream,
            kWaveFormatExGuid,
            &waveFormat);
    }
    if (SUCCEEDED(result)) {
        result = voice->SetOutput(speechStream, TRUE);
    }

    size_t textOffset = 0;
    while (SUCCEEDED(result) && textOffset < request.text.size()) {
        if (stopRequested.load()) {
            result = CancellationResult();
            break;
        }

        const size_t chunkEnd =
            FindSpeechChunkEnd(request.text, textOffset);
        const std::wstring chunk =
            request.text.substr(textOffset, chunkEnd - textOffset);
        const int voiceTimbre =
            std::clamp(request.settings.voiceTimbre, -10, 10);
        const bool applyTimbre = voiceTimbre != 0;
        const std::wstring spokenChunk =
            applyTimbre
                ? BuildTimbreMarkup(chunk, voiceTimbre)
                : chunk;
        result = voice->Speak(
            spokenChunk.c_str(),
            static_cast<DWORD>(
                SPF_ASYNC |
                (applyTimbre ? SPF_IS_XML : SPF_IS_NOT_XML)),
            nullptr);
        if (SUCCEEDED(result)) {
            result = WaitForSpeechChunk(voice, stopRequested);
        }
        if (SUCCEEDED(result)) {
            result = speechStream->Commit(STGC_DEFAULT);
        }
        if (SUCCEEDED(result)) {
            result = CheckRenderedSpeechSize(memoryStream);
        }
        textOffset = chunkEnd;
    }

    if (SUCCEEDED(result)) {
        result = speechStream->Commit(STGC_DEFAULT);
    }

    if (SUCCEEDED(result)) {
        STATSTG statistics = {};
        result = memoryStream->Stat(&statistics, STATFLAG_NONAME);
        if (SUCCEEDED(result)) {
            const ULONGLONG byteCount64 =
                static_cast<ULONGLONG>(statistics.cbSize.QuadPart);
            if (byteCount64 == 0 ||
                (byteCount64 % sizeof(int16_t)) != 0 ||
                byteCount64 > kMaxRenderedSpeechBytes ||
                byteCount64 > static_cast<ULONGLONG>(
                                  std::numeric_limits<size_t>::max())) {
                result =
                    byteCount64 > kMaxRenderedSpeechBytes
                        ? LitanyTooLongResult()
                        : E_FAIL;
            } else {
                HGLOBAL memoryHandle = nullptr;
                result = GetHGlobalFromStream(memoryStream, &memoryHandle);
                if (SUCCEEDED(result) && memoryHandle) {
                    const void* rawBytes = GlobalLock(memoryHandle);
                    if (!rawBytes) {
                        result = HRESULT_FROM_WIN32(GetLastError());
                    } else {
                        const size_t sampleCount =
                            static_cast<size_t>(byteCount64 / sizeof(int16_t));
                        const int16_t* source =
                            static_cast<const int16_t*>(rawBytes);
                        samples.resize(sampleCount);
                        for (size_t index = 0; index < sampleCount; ++index) {
                            samples[index] =
                                static_cast<float>(source[index]) / 32768.0f;
                        }
                        GlobalUnlock(memoryHandle);
                    }
                }
            }
        }
    }

    if (voice) {
        voice->SetOutput(nullptr, TRUE);
    }
    SafeRelease(speechStream);
    SafeRelease(memoryStream);
    SafeRelease(voice);
    return result;
}

uint32_t HashText(const std::wstring& text) {
    uint32_t value = 2166136261u;
    for (wchar_t character : text) {
        value ^= static_cast<uint32_t>(character);
        value *= 16777619u;
    }
    return value ? value : 0xA17E5A11u;
}

uint32_t NextRandom(uint32_t& state) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return state;
}

float SmoothClip(float value) {
    return static_cast<float>(std::tanh(value));
}

std::vector<float> ProcessVox(
    const std::vector<float>& input,
    const AudioSettings& settings,
    std::atomic<bool>& stopRequested) {
    const float timbre =
        std::clamp(settings.voiceTimbre, -10, 10) / 10.0f;
    const float timbreAmount = std::abs(timbre);
    const float mechanical =
        settings.mechanicalEnabled ? settings.mechanical / 100.0f : 0.0f;
    const float distortion =
        settings.mechanicalEnabled ? settings.distortion / 100.0f : 0.0f;
    const float bitcrush =
        settings.mechanicalEnabled ? settings.bitcrush / 100.0f : 0.0f;
    const float resonance =
        settings.mechanicalEnabled ? settings.resonance / 100.0f : 0.0f;

    if (timbreAmount <= 0.001f &&
        mechanical <= 0.001f && distortion <= 0.001f &&
        bitcrush <= 0.001f && resonance <= 0.001f) {
        return input;
    }

    const size_t effectTail =
        resonance > 0.001f
            ? static_cast<size_t>(
                  kSampleRate * (0.08f + resonance * 0.92f))
            : 0;
    std::vector<float> output(input.size() + effectTail, 0.0f);

    const float highPassCutoff = 70.0f + mechanical * 170.0f;
    const float highPassRc = 1.0f / (2.0f * static_cast<float>(kPi) * highPassCutoff);
    const float timeStep = 1.0f / static_cast<float>(kSampleRate);
    const float highPassAlpha = highPassRc / (highPassRc + timeStep);

    const float lowPassCutoff = 7600.0f - mechanical * 3900.0f;
    const float lowPassRc = 1.0f / (2.0f * static_cast<float>(kPi) * lowPassCutoff);
    const float lowPassAlpha = timeStep / (lowPassRc + timeStep);

    // Pitch is requested from SAPI during synthesis. This independent spectral
    // contour guarantees an audible timbre change even when a third-party
    // engine only partially honours SAPI pitch metadata.
    const float timbreCutoff =
        timbre < 0.0f
            ? 7200.0f - timbreAmount * 4600.0f
            : 2600.0f - timbreAmount * 700.0f;
    const float timbreRc =
        1.0f /
        (2.0f * static_cast<float>(kPi) * timbreCutoff);
    const float timbreAlpha = timeStep / (timbreRc + timeStep);

    const int bitDepth = std::clamp(
        16 - static_cast<int>(std::round(bitcrush * 9.0f)),
        7,
        16);
    const float quantizationSteps =
        static_cast<float>((1u << (bitDepth - 1)) - 1u);
    const int sampleHold =
        1 + static_cast<int>(std::round(bitcrush * 5.0f));

    const size_t combDelay =
        std::max<size_t>(
            1,
            static_cast<size_t>(
                kSampleRate * (0.0035f + resonance * 0.0130f)));
    const size_t secondDelay =
        std::max<size_t>(
            1,
            static_cast<size_t>(
                kSampleRate * (0.0110f + resonance * 0.0240f)));
    const float combFeedback = resonance * 0.52f;
    const float secondFeedback = resonance * 0.18f;

    float previousInput = 0.0f;
    float highPass = 0.0f;
    float lowPass = 0.0f;
    float timbreLowPass = 0.0f;
    float heldSample = 0.0f;
    const float drive = 1.0f + distortion * 8.5f;
    const float driveNormalization =
        std::max(0.001f, static_cast<float>(std::tanh(drive)));
    const float robotFrequency = 27.0f + mechanical * 34.0f;

    for (size_t index = 0; index < output.size(); ++index) {
        if ((index & 0x3FFFu) == 0 && stopRequested.load()) {
            return {};
        }

        const float source = index < input.size() ? input[index] : 0.0f;
        float current = source;

        if (timbreAmount > 0.001f) {
            timbreLowPass +=
                timbreAlpha * (current - timbreLowPass);
            if (timbre < 0.0f) {
                const float darkMix =
                    std::clamp(timbreAmount * 0.78f, 0.0f, 0.82f);
                current =
                    current * (1.0f - darkMix) +
                    timbreLowPass * darkMix;
            } else {
                const float brightness =
                    current - timbreLowPass;
                current +=
                    brightness *
                    std::clamp(timbreAmount * 0.72f, 0.0f, 0.75f);
            }
        }

        if (mechanical > 0.001f) {
            const float mechanicalInput = current;
            highPass =
                highPassAlpha *
                (highPass + mechanicalInput - previousInput);
            previousInput = mechanicalInput;
            lowPass += lowPassAlpha * (highPass - lowPass);
            const float carrier =
                0.80f +
                0.20f * static_cast<float>(
                            std::sin(
                                2.0 * kPi * robotFrequency *
                                static_cast<double>(index) /
                                kSampleRate));
            const float mechanicalSignal = lowPass * carrier;
            const float mechanicalMix =
                std::clamp(mechanical * 0.78f, 0.0f, 0.90f);
            current =
                current * (1.0f - mechanicalMix) +
                mechanicalSignal * mechanicalMix;
        }

        if (bitcrush > 0.001f) {
            if (index % static_cast<size_t>(sampleHold) == 0) {
                heldSample =
                    std::round(current * quantizationSteps) /
                    quantizationSteps;
            }
            const float bitcrushMix =
                std::clamp(bitcrush * 0.92f, 0.0f, 0.92f);
            current =
                current * (1.0f - bitcrushMix) +
                heldSample * bitcrushMix;
        }

        if (distortion > 0.001f) {
            const float driven =
                SmoothClip(current * drive) / driveNormalization;
            const float distortionMix =
                std::clamp(distortion * 0.82f, 0.0f, 0.86f);
            current =
                current * (1.0f - distortionMix) +
                driven * distortionMix;
        }

        if (resonance > 0.001f) {
            float resonant = current;
            if (index >= combDelay) {
                resonant +=
                    output[index - combDelay] * combFeedback;
            }
            if (index >= secondDelay) {
                resonant -=
                    output[index - secondDelay] * secondFeedback;
            }
            const float resonanceMix =
                std::clamp(resonance * 0.72f, 0.0f, 0.78f);
            current =
                current * (1.0f - resonanceMix) +
                resonant * resonanceMix;
        }

        output[index] = std::clamp(current, -2.0f, 2.0f);
    }

    return output;
}

void AddBinaryTelemetry(
    std::vector<float>& left,
    std::vector<float>& right,
    const std::vector<float>& speech,
    size_t preRoll,
    const RitualRequest& request,
    std::atomic<bool>& stopRequested) {
    if (!request.settings.binaryEnabled ||
        request.settings.binaryVolume <= 0) {
        return;
    }

    const float level = request.settings.binaryVolume / 100.0f;
    uint32_t randomState = HashText(request.text) ^ 0x4D414749u;
    size_t cursor = preRoll + static_cast<size_t>(kSampleRate * 0.85);
    // The single "binary code" control governs both loudness and activity:
    // low values produce occasional telemetry, high values a dense data rite.
    const size_t minimumGap =
        static_cast<size_t>(kSampleRate * (3.60 - level * 1.80));
    const size_t variableGap =
        static_cast<size_t>(kSampleRate * (2.40 - level * 1.20));
    const size_t bitTone = static_cast<size_t>(kSampleRate * 0.040);
    const size_t bitGap = static_cast<size_t>(kSampleRate * 0.020);

    while (cursor + (bitTone + bitGap) * 10 < left.size()) {
        if (stopRequested.load()) {
            return;
        }

        size_t bestCursor = cursor;
        float bestEnergy = std::numeric_limits<float>::max();
        const size_t searchWindow = static_cast<size_t>(kSampleRate * 1.1);
        const size_t searchStep = static_cast<size_t>(kSampleRate * 0.055);
        for (size_t probe = cursor;
             probe < std::min(cursor + searchWindow, left.size());
             probe += std::max<size_t>(1, searchStep)) {
            float energy = 0.0f;
            const size_t speechStart =
                probe > preRoll ? probe - preRoll : 0;
            for (size_t offset = 0;
                 offset < static_cast<size_t>(kSampleRate * 0.14) &&
                 speechStart + offset < speech.size();
                 offset += 31) {
                energy += std::abs(speech[speechStart + offset]);
            }
            if (energy < bestEnergy) {
                bestEnergy = energy;
                bestCursor = probe;
            }
        }

        const uint32_t word = NextRandom(randomState);
        const bool panRight = (word & 1u) != 0;
        for (int bitIndex = 0; bitIndex < 10; ++bitIndex) {
            const bool one =
                bitIndex == 0 || bitIndex == 9
                    ? bitIndex == 9
                    : ((word >> (bitIndex - 1)) & 1u) != 0;
            const float baseFrequency = one ? 1110.0f : 690.0f;
            const size_t toneStart =
                bestCursor +
                static_cast<size_t>(bitIndex) * (bitTone + bitGap);

            for (size_t sample = 0;
                 sample < bitTone && toneStart + sample < left.size();
                 ++sample) {
                const float phase =
                    static_cast<float>(sample) /
                    std::max<size_t>(1, bitTone - 1);
                const float envelope =
                    std::sin(static_cast<float>(kPi) * phase);
                const float chirp =
                    baseFrequency + (one ? 90.0f : -55.0f) * phase;
                const float tone =
                    std::sin(
                        static_cast<float>(
                            2.0 * kPi * chirp * sample / kSampleRate));
                const float pulse =
                    tone * envelope * level * 0.24f;
                if (panRight) {
                    left[toneStart + sample] += pulse * 0.46f;
                    right[toneStart + sample] += pulse;
                } else {
                    left[toneStart + sample] += pulse;
                    right[toneStart + sample] += pulse * 0.46f;
                }
            }
        }

        cursor =
            bestCursor +
            minimumGap +
            static_cast<size_t>(
                NextRandom(randomState) /
                static_cast<double>(std::numeric_limits<uint32_t>::max()) *
                variableGap);
    }
}

void MixLiturgicalBed(
    std::vector<float>& left,
    std::vector<float>& right,
    const std::vector<float>& speech,
    size_t preRoll,
    const RitualRequest& request,
    std::atomic<bool>& stopRequested) {
    const float organLevel = request.settings.organVolume / 100.0f;
    const float choirLevel = request.settings.choirVolume / 100.0f;
    if (organLevel <= 0.001f && choirLevel <= 0.001f) {
        return;
    }

    std::array<double, 4> organPhase = {};
    std::array<double, 5> choirPhase = {};
    float breathNoise = 0.0f;
    uint32_t randomState = HashText(request.text) ^ 0x4F4D4E49u;
    float speechEnvelope = 0.0f;
    const size_t fadeSamples = static_cast<size_t>(kSampleRate * 0.9);

    for (size_t index = 0; index < left.size(); ++index) {
        if ((index & 0x3FFFu) == 0 && stopRequested.load()) {
            return;
        }

        const float fadeIn =
            std::min(1.0f, index / static_cast<float>(std::max<size_t>(1, fadeSamples)));
        const size_t remaining = left.size() - index;
        const float fadeOut =
            std::min(
                1.0f,
                remaining /
                    static_cast<float>(std::max<size_t>(1, fadeSamples)));
        const float fade = fadeIn * fadeOut;

        const size_t speechIndex =
            index >= preRoll ? index - preRoll : speech.size();
        const float speechValue =
            speechIndex < speech.size() ? std::abs(speech[speechIndex]) : 0.0f;
        speechEnvelope +=
            (speechValue - speechEnvelope) *
            (speechValue > speechEnvelope ? 0.025f : 0.0015f);
        const float duck = 1.0f - std::min(0.42f, speechEnvelope * 0.65f);

        const double seconds = static_cast<double>(index) / kSampleRate;
        const int chord = static_cast<int>(seconds / 12.0) % 4;
        static constexpr std::array<double, 4> roots = {
            55.000, 49.000, 65.406, 55.000};
        const double root = roots[chord];
        const std::array<double, 4> organFrequencies = {
            root,
            root * 1.5,
            root * 2.0,
            root * 2.6666667};

        float organ = 0.0f;
        for (size_t voice = 0; voice < organPhase.size(); ++voice) {
            const double tremolo =
                1.0 + 0.0015 * std::sin(seconds * 0.19 + voice);
            organPhase[voice] +=
                2.0 * kPi * organFrequencies[voice] * tremolo /
                kSampleRate;
            if (organPhase[voice] > 2.0 * kPi) {
                organPhase[voice] -= 2.0 * kPi;
            }
            const float fundamental =
                static_cast<float>(std::sin(organPhase[voice]));
            const float harmonic =
                static_cast<float>(std::sin(organPhase[voice] * 2.0));
            organ += fundamental * (0.33f / (voice + 1.0f));
            organ += harmonic * (0.08f / (voice + 1.0f));
        }

        const std::array<double, 5> choirFrequencies = {
            root * 2.0 * 0.997,
            root * 2.5 * 1.003,
            root * 3.0 * 0.999,
            root * 4.0 * 1.001,
            root * 5.0 * 0.998};
        float choir = 0.0f;
        for (size_t voice = 0; voice < choirPhase.size(); ++voice) {
            choirPhase[voice] +=
                2.0 * kPi * choirFrequencies[voice] / kSampleRate;
            if (choirPhase[voice] > 2.0 * kPi) {
                choirPhase[voice] -= 2.0 * kPi;
            }
            choir +=
                static_cast<float>(std::sin(choirPhase[voice])) *
                (0.19f / (1.0f + voice * 0.35f));
        }

        const float whiteNoise =
            (static_cast<int32_t>(NextRandom(randomState)) /
             static_cast<float>(std::numeric_limits<int32_t>::max())) *
            0.5f;
        breathNoise += (whiteNoise - breathNoise) * 0.012f;
        choir += breathNoise * 0.22f;

        const float organGain = organLevel * 0.35f * fade * duck;
        const float choirGain = choirLevel * 0.22f * fade * duck;
        const float stereoLfo =
            static_cast<float>(std::sin(seconds * 0.31));

        left[index] +=
            organ * organGain * (0.94f + stereoLfo * 0.04f) +
            choir * choirGain * (0.92f - stereoLfo * 0.06f);
        right[index] +=
            organ * organGain * (0.94f - stereoLfo * 0.04f) +
            choir * choirGain * (0.92f + stereoLfo * 0.06f);
    }
}

HRESULT BuildFinalPcm(
    const std::vector<float>& rawSpeech,
    const RitualRequest& request,
    std::atomic<bool>& stopRequested,
    std::vector<int16_t>& interleavedPcm) {
    std::vector<float> processed =
        ProcessVox(rawSpeech, request.settings, stopRequested);
    if (stopRequested.load() || processed.empty()) {
        return CancellationResult();
    }

    const bool hasLiturgicalBed =
        request.settings.organVolume > 0 ||
        request.settings.choirVolume > 0 ||
        (request.settings.binaryEnabled &&
         request.settings.binaryVolume > 0);
    const size_t preRoll =
        static_cast<size_t>(
            kSampleRate * (hasLiturgicalBed ? 0.48 : 0.04));
    const size_t postRoll =
        static_cast<size_t>(
            kSampleRate * (hasLiturgicalBed ? 0.58 : 0.04));
    const size_t frameCount = preRoll + processed.size() + postRoll;
    std::vector<float> left(frameCount, 0.0f);
    std::vector<float> right(frameCount, 0.0f);

    const float voiceGain = request.settings.speechVolume / 100.0f * 0.90f;
    const size_t shadowDelay =
        request.settings.mechanicalEnabled &&
                request.settings.mechanical > 0
            ? static_cast<size_t>(
                  kSampleRate *
                  (0.004 +
                   request.settings.mechanical / 100.0 * 0.012))
            : 0;

    uint32_t noiseState = HashText(request.text) ^ 0xC001D00Du;
    for (size_t index = 0; index < processed.size(); ++index) {
        if ((index & 0x3FFFu) == 0 && stopRequested.load()) {
            return CancellationResult();
        }
        const size_t destination = preRoll + index;
        float direct = processed[index] * voiceGain;
        float shadow = 0.0f;
        if (shadowDelay > 0 && index >= shadowDelay) {
            shadow = processed[index - shadowDelay] *
                     voiceGain *
                     (request.settings.mechanical / 100.0f) *
                     0.16f;
        }
        const float noise =
            request.settings.mechanicalEnabled &&
                    request.settings.mechanical > 0
                ? (static_cast<int32_t>(NextRandom(noiseState)) /
                   static_cast<float>(
                       std::numeric_limits<int32_t>::max())) *
                      (request.settings.mechanical / 100.0f) *
                      0.0065f
                : 0.0f;
        left[destination] += direct + shadow + noise;
        right[destination] += direct - shadow * 0.55f - noise * 0.35f;
    }

    MixLiturgicalBed(
        left,
        right,
        processed,
        preRoll,
        request,
        stopRequested);
    AddBinaryTelemetry(
        left,
        right,
        processed,
        preRoll,
        request,
        stopRequested);
    if (stopRequested.load()) {
        return CancellationResult();
    }

    float peak = 0.001f;
    for (size_t index = 0; index < frameCount; ++index) {
        peak = std::max(peak, std::abs(left[index]));
        peak = std::max(peak, std::abs(right[index]));
    }
    const float normalization = peak > 0.94f ? 0.94f / peak : 1.0f;

    interleavedPcm.resize(frameCount * 2);
    for (size_t index = 0; index < frameCount; ++index) {
        const float leftLimited =
            std::clamp(
                left[index] * normalization,
                -0.96f,
                0.96f);
        const float rightLimited =
            std::clamp(
                right[index] * normalization,
                -0.96f,
                0.96f);
        interleavedPcm[index * 2] =
            static_cast<int16_t>(
                std::clamp(leftLimited, -1.0f, 1.0f) * 32767.0f);
        interleavedPcm[index * 2 + 1] =
            static_cast<int16_t>(
                std::clamp(rightLimited, -1.0f, 1.0f) * 32767.0f);
    }

    return S_OK;
}

HRESULT PlayPcm(
    std::vector<int16_t>& pcm,
    std::atomic<bool>& stopRequested,
    std::atomic<int>& playbackPositionMs,
    std::atomic<int>& playbackLengthMs) {
    if (pcm.empty() ||
        pcm.size() * sizeof(int16_t) >
            static_cast<size_t>(std::numeric_limits<DWORD>::max())) {
        return E_INVALIDARG;
    }

    WAVEFORMATEX format = {};
    format.wFormatTag = WAVE_FORMAT_PCM;
    format.nChannels = 2;
    format.nSamplesPerSec = kSampleRate;
    format.wBitsPerSample = 16;
    format.nBlockAlign =
        static_cast<WORD>(format.nChannels * format.wBitsPerSample / 8);
    format.nAvgBytesPerSec = format.nSamplesPerSec * format.nBlockAlign;

    HANDLE eventHandle = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!eventHandle) {
        return HRESULT_FROM_WIN32(GetLastError());
    }

    HWAVEOUT waveOutput = nullptr;
    MMRESULT waveResult = waveOutOpen(
        &waveOutput,
        WAVE_MAPPER,
        &format,
        reinterpret_cast<DWORD_PTR>(eventHandle),
        0,
        CALLBACK_EVENT);
    if (waveResult != MMSYSERR_NOERROR) {
        CloseHandle(eventHandle);
        return WaveResultToHresult(waveResult);
    }

    WAVEHDR header = {};
    header.lpData = reinterpret_cast<LPSTR>(pcm.data());
    header.dwBufferLength =
        static_cast<DWORD>(pcm.size() * sizeof(int16_t));

    bool headerPrepared = false;
    waveResult = waveOutPrepareHeader(waveOutput, &header, sizeof(header));
    if (waveResult == MMSYSERR_NOERROR) {
        headerPrepared = true;
        ResetEvent(eventHandle);
        waveResult = waveOutWrite(waveOutput, &header, sizeof(header));
    }

    const int totalMilliseconds =
        static_cast<int>(
            (pcm.size() / 2) * 1000ULL / kSampleRate);
    playbackLengthMs.store(totalMilliseconds);
    playbackPositionMs.store(0);

    bool canceled = false;
    HRESULT playbackResult =
        waveResult == MMSYSERR_NOERROR
            ? S_OK
            : WaveResultToHresult(waveResult);
    if (waveResult == MMSYSERR_NOERROR) {
        const ULONGLONG startTick = GetTickCount64();
        const ULONGLONG timeoutMilliseconds =
            static_cast<ULONGLONG>(totalMilliseconds) + 30000ULL;
        while ((header.dwFlags & WHDR_DONE) == 0) {
            if (stopRequested.load()) {
                canceled = true;
                waveOutReset(waveOutput);
                break;
            }

            MMTIME position = {};
            position.wType = TIME_SAMPLES;
            if (waveOutGetPosition(
                    waveOutput,
                    &position,
                    sizeof(position)) == MMSYSERR_NOERROR) {
                playbackPositionMs.store(
                    std::min(
                        totalMilliseconds,
                        static_cast<int>(
                            position.u.sample * 1000ULL /
                            kSampleRate)));
            }

            const DWORD waitResult =
                WaitForSingleObject(eventHandle, 45);
            if (waitResult == WAIT_FAILED) {
                playbackResult =
                    HRESULT_FROM_WIN32(GetLastError());
                waveOutReset(waveOutput);
                break;
            }
            if (GetTickCount64() - startTick > timeoutMilliseconds) {
                playbackResult =
                    HRESULT_FROM_WIN32(ERROR_TIMEOUT);
                waveOutReset(waveOutput);
                break;
            }
        }
    }

    if (!canceled && SUCCEEDED(playbackResult)) {
        playbackPositionMs.store(totalMilliseconds);
    }

    if (headerPrepared) {
        MMRESULT unprepareResult = WAVERR_STILLPLAYING;
        for (int attempt = 0; attempt < 200; ++attempt) {
            unprepareResult =
                waveOutUnprepareHeader(
                    waveOutput,
                    &header,
                    sizeof(header));
            if (unprepareResult != WAVERR_STILLPLAYING) {
                break;
            }
            if (attempt == 0) {
                waveOutReset(waveOutput);
            }
            Sleep(10);
        }
        if (unprepareResult != MMSYSERR_NOERROR &&
            SUCCEEDED(playbackResult)) {
            playbackResult =
                WaveResultToHresult(unprepareResult);
        }
    }

    const MMRESULT closeResult = waveOutClose(waveOutput);
    if (closeResult != MMSYSERR_NOERROR &&
        SUCCEEDED(playbackResult)) {
        playbackResult = WaveResultToHresult(closeResult);
    }
    CloseHandle(eventHandle);

    if (canceled) {
        return CancellationResult();
    }
    return playbackResult;
}

}  // namespace

std::vector<VoiceInfo> EnumerateSapiVoices() {
    std::vector<VoiceInfo> voices;
    ISpVoice* sapiVoice = nullptr;
    IEnumSpObjectTokens* enumerator = nullptr;
    ISpObjectToken* defaultToken = nullptr;
    std::wstring defaultTokenId;

    try {
        HRESULT result = CoCreateInstance(
            CLSID_SpVoice,
            nullptr,
            CLSCTX_ALL,
            __uuidof(ISpVoice),
            reinterpret_cast<void**>(&sapiVoice));
        if (FAILED(result)) {
            return voices;
        }

        if (SUCCEEDED(sapiVoice->GetVoice(&defaultToken))) {
            defaultTokenId = ReadTokenId(defaultToken);
        }

        result = SpEnumTokens(
            SPCAT_VOICES,
            nullptr,
            nullptr,
            &enumerator);
        if (SUCCEEDED(result)) {
            ULONG count = 0;
            enumerator->GetCount(&count);
            for (ULONG index = 0; index < count; ++index) {
                ISpObjectToken* token = nullptr;
                ULONG fetched = 0;
                if (enumerator->Next(1, &token, &fetched) != S_OK ||
                    !token) {
                    continue;
                }

                try {
                    VoiceInfo info;
                    info.id = ReadTokenId(token);
                    std::wstring name = ReadTokenString(token, nullptr);
                    if (name.empty()) {
                        name = L"Безымянный голос Windows";
                    }
                    const std::wstring language =
                        DescribeLanguage(
                            ReadTokenString(token, L"Language"));
                    std::wstring gender =
                        ReadTokenString(token, L"Gender");
                    if (gender.empty()) {
                        gender = L"не указан";
                    }
                    info.isDefault =
                        !defaultTokenId.empty() &&
                        info.id == defaultTokenId;
                    info.displayName =
                        name + L"  ·  " + language + L"  ·  " + gender;
                    if (info.isDefault) {
                        info.displayName += L"  [по умолчанию]";
                    }
                    voices.push_back(std::move(info));
                } catch (...) {
                    SafeRelease(token);
                    throw;
                }
                SafeRelease(token);
            }
        }
    } catch (...) {
        voices.clear();
    }

    SafeRelease(defaultToken);
    SafeRelease(enumerator);
    SafeRelease(sapiVoice);
    return voices;
}

HRESULT RunRitualAudio(
    const RitualRequest& request,
    std::atomic<bool>& stopRequested,
    std::atomic<int>& playbackPositionMs,
    std::atomic<int>& playbackLengthMs,
    const RitualStatusCallback& statusCallback) {
    playbackPositionMs.store(0);
    playbackLengthMs.store(0);

    HRESULT result = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    const bool comInitialized =
        result == S_OK || result == S_FALSE;
    if (!comInitialized && result != RPC_E_CHANGED_MODE) {
        return result;
    }

    try {
        if (statusCallback) {
            statusCallback(RitualStage::Synthesizing);
        }

        std::vector<float> rawSpeech;
        result = RenderSpeechToMemory(
            request,
            stopRequested,
            rawSpeech,
            statusCallback);

        if (SUCCEEDED(result) && stopRequested.load()) {
            result = CancellationResult();
        }

        if (SUCCEEDED(result)) {
            if (statusCallback) {
                statusCallback(RitualStage::Processing);
            }
            std::vector<int16_t> finalPcm;
            result = BuildFinalPcm(
                rawSpeech,
                request,
                stopRequested,
                finalPcm);
            if (SUCCEEDED(result) && stopRequested.load()) {
                result = CancellationResult();
            }
            if (SUCCEEDED(result)) {
                if (statusCallback) {
                    statusCallback(RitualStage::Playing);
                }
                result = PlayPcm(
                    finalPcm,
                    stopRequested,
                    playbackPositionMs,
                    playbackLengthMs);
            }
        }
    } catch (const std::bad_alloc&) {
        result = E_OUTOFMEMORY;
    } catch (const std::exception&) {
        result = E_UNEXPECTED;
    } catch (...) {
        result = E_UNEXPECTED;
    }

    if (comInitialized) {
        CoUninitialize();
    }
    return result;
}

std::wstring DescribeAudioResult(HRESULT result) {
    MMRESULT waveResult = MMSYSERR_NOERROR;
    if (!TryGetWaveResult(result, waveResult)) {
        return {};
    }

    wchar_t message[MAXERRORLENGTH] = {};
    if (waveOutGetErrorTextW(
            waveResult,
            message,
            static_cast<UINT>(std::size(message))) ==
        MMSYSERR_NOERROR) {
        return message;
    }
    return L"Windows не удалось открыть или завершить аудиоканал.";
}
