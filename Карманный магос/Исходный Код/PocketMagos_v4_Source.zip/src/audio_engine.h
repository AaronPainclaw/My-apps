#pragma once

#include <windows.h>

#include <atomic>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

struct VoiceInfo {
    std::wstring id;
    std::wstring displayName;
    bool isDefault = false;
};

struct AudioSettings {
    int speechRate = -1;
    int speechVolume = 92;
    int voiceTimbre = -2;
    int mechanical = 62;
    int distortion = 34;
    int bitcrush = 22;
    int resonance = 56;
    int binaryVolume = 34;
    int organVolume = 34;
    int choirVolume = 28;
    bool mechanicalEnabled = true;
    bool binaryEnabled = true;
};

struct RitualRequest {
    std::wstring text;
    std::wstring voiceTokenId;
    AudioSettings settings;
};

enum class RitualStage : std::uint32_t {
    Synthesizing = 1,
    VoiceFallback,
    Processing,
    Playing,
};

using RitualStatusCallback = std::function<void(RitualStage)>;

std::vector<VoiceInfo> EnumerateSapiVoices();

HRESULT RunRitualAudio(
    const RitualRequest& request,
    std::atomic<bool>& stopRequested,
    std::atomic<int>& playbackPositionMs,
    std::atomic<int>& playbackLengthMs,
    const RitualStatusCallback& statusCallback);

std::wstring DescribeAudioResult(HRESULT result);
