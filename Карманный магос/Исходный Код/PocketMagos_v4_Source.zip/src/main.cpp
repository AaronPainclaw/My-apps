#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <commdlg.h>
#include <dwmapi.h>
#include <process.h>

#include "audio_engine.h"
#include "resource.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cwctype>
#include <exception>
#include <limits>
#include <memory>
#include <new>
#include <string>
#include <vector>

namespace {

constexpr wchar_t kMainWindowClass[] = L"PocketMagosV40.MainWindow";
constexpr wchar_t kSliderWindowClass[] = L"PocketMagosV40.Slider";
constexpr wchar_t kRegistryPath[] = L"Software\\PocketMagos\\4.0";
constexpr wchar_t kLegacyRegistryPath32[] = L"Software\\PocketMagos\\3.2";
constexpr wchar_t kLegacyRegistryPath31[] = L"Software\\PocketMagos\\3.1";
constexpr wchar_t kLegacyRegistryPath30[] = L"Software\\PocketMagos\\3.0";

constexpr int kClientWidth = 1160;
constexpr int kClientHeight = 780;
constexpr size_t kMaxEditorCharacters = 1000000;
constexpr LONGLONG kMaxLitanyFileBytes = 8LL * 1024LL * 1024LL;
constexpr UINT_PTR kAnimationTimerId = 1;
constexpr UINT kAnimationPeriodMs = 100;
constexpr UINT kMinimumLayoutDpi = 72;

constexpr COLORREF kBackground = RGB(8, 9, 11);
constexpr COLORREF kPanel = RGB(18, 19, 22);
constexpr COLORREF kPanelRaised = RGB(26, 26, 30);
constexpr COLORREF kPanelLight = RGB(34, 34, 39);
constexpr COLORREF kCrimson = RGB(155, 20, 34);
constexpr COLORREF kCrimsonBright = RGB(222, 39, 57);
constexpr COLORREF kCrimsonDark = RGB(72, 10, 18);
constexpr COLORREF kBone = RGB(220, 210, 183);
constexpr COLORREF kSteel = RGB(135, 145, 153);
constexpr COLORREF kText = RGB(229, 225, 216);
constexpr COLORREF kMutedText = RGB(151, 148, 143);
constexpr COLORREF kBinaryGreen = RGB(112, 178, 124);

enum ControlId : int {
    IDC_LITANY_EDIT = 1000,
    IDC_VOICE_COMBO,
    IDC_PRESET_COMBO,
    IDC_MECHANICAL_CHECK,
    IDC_BINARY_CHECK,
    IDC_OPEN_BUTTON,
    IDC_SAVE_BUTTON,
    IDC_START_BUTTON,
    IDC_STOP_BUTTON,
    IDC_TEST_BUTTON,
    IDC_COUNTER_LABEL,
    IDC_STATUS_LABEL,

    IDC_SLIDER_RATE = 1100,
    IDC_SLIDER_SPEECH,
    IDC_SLIDER_TIMBRE,
    IDC_SLIDER_MECHANICAL,
    IDC_SLIDER_DISTORTION,
    IDC_SLIDER_BITCRUSH,
    IDC_SLIDER_RESONANCE,
    IDC_SLIDER_BINARY,
    IDC_SLIDER_ORGAN,
    IDC_SLIDER_CHOIR,

    IDC_VALUE_RATE = 1200,
    IDC_VALUE_SPEECH,
    IDC_VALUE_TIMBRE,
    IDC_VALUE_MECHANICAL,
    IDC_VALUE_DISTORTION,
    IDC_VALUE_BITCRUSH,
    IDC_VALUE_RESONANCE,
    IDC_VALUE_BINARY,
    IDC_VALUE_ORGAN,
    IDC_VALUE_CHOIR,
};

constexpr UINT WM_MAGOS_STATUS = WM_APP + 10;
constexpr UINT WM_MAGOS_FINISHED = WM_APP + 11;

struct SliderState {
    int minimum = 0;
    int maximum = 100;
    int value = 0;
    bool dragging = false;
};

struct SliderBinding {
    int sliderId;
    int valueId;
    const wchar_t* label;
    int minimum;
    int maximum;
};

struct RegistryKeyGuard {
    HKEY key = nullptr;

    ~RegistryKeyGuard() {
        if (key) {
            RegCloseKey(key);
        }
    }
};

struct BackBuffer {
    HDC device = nullptr;
    HBITMAP bitmap = nullptr;
    HGDIOBJ previousBitmap = nullptr;
    int width = 0;
    int height = 0;

    BackBuffer() = default;
    BackBuffer(const BackBuffer&) = delete;
    BackBuffer& operator=(const BackBuffer&) = delete;

    ~BackBuffer() {
        Reset();
    }

    void Reset() {
        if (device && previousBitmap) {
            SelectObject(device, previousBitmap);
        }
        if (bitmap) {
            DeleteObject(bitmap);
        }
        if (device) {
            DeleteDC(device);
        }
        device = nullptr;
        bitmap = nullptr;
        previousBitmap = nullptr;
        width = 0;
        height = 0;
    }

    bool Ensure(HDC reference, int requestedWidth, int requestedHeight) {
        if (device && bitmap &&
            width == requestedWidth &&
            height == requestedHeight) {
            return true;
        }

        Reset();
        if (!reference || requestedWidth <= 0 || requestedHeight <= 0) {
            return false;
        }

        device = CreateCompatibleDC(reference);
        if (!device) {
            return false;
        }
        bitmap = CreateCompatibleBitmap(
            reference,
            requestedWidth,
            requestedHeight);
        if (!bitmap) {
            Reset();
            return false;
        }
        previousBitmap = SelectObject(device, bitmap);
        if (!previousBitmap ||
            previousBitmap == HGDI_ERROR) {
            previousBitmap = nullptr;
            Reset();
            return false;
        }
        width = requestedWidth;
        height = requestedHeight;
        return true;
    }
};

constexpr std::array<SliderBinding, 10> kSliderBindings = {{
    {IDC_SLIDER_RATE, IDC_VALUE_RATE, L"Темп речи", -10, 10},
    {IDC_SLIDER_SPEECH, IDC_VALUE_SPEECH, L"Громкость гласа", 0, 100},
    {IDC_SLIDER_TIMBRE, IDC_VALUE_TIMBRE, L"Тембр голоса", -10, 10},
    {IDC_SLIDER_MECHANICAL, IDC_VALUE_MECHANICAL, L"Механизация", 0, 100},
    {IDC_SLIDER_DISTORTION, IDC_VALUE_DISTORTION, L"Вокс-искажение", 0, 100},
    {IDC_SLIDER_BITCRUSH, IDC_VALUE_BITCRUSH, L"Цифровое зерно", 0, 100},
    {IDC_SLIDER_RESONANCE, IDC_VALUE_RESONANCE, L"Резонанс металла", 0, 100},
    {IDC_SLIDER_BINARY, IDC_VALUE_BINARY, L"Бинарный код", 0, 100},
    {IDC_SLIDER_ORGAN, IDC_VALUE_ORGAN, L"Орган", 0, 100},
    {IDC_SLIDER_CHOIR, IDC_VALUE_CHOIR, L"Хор Духа Машины", 0, 100},
}};

constexpr std::array<int, 10> kDefaultSliderValues = {
    -1, 92, -2, 62, 34, 22, 56, 34, 34, 28};
constexpr std::array<int, 9> kLegacyDefaultSliderValues = {
    -1, 92, 62, 34, 22, 56, 34, 34, 28};
constexpr std::array<size_t, 9> kLegacySliderMapping = {
    0, 1, 3, 4, 5, 6, 7, 8, 9};

HINSTANCE g_instance = nullptr;
HWND g_mainWindow = nullptr;
HWND g_litanyEdit = nullptr;
HWND g_voiceCombo = nullptr;
HWND g_presetCombo = nullptr;
HWND g_mechanicalCheck = nullptr;
HWND g_binaryCheck = nullptr;
HWND g_openButton = nullptr;
HWND g_saveButton = nullptr;
HWND g_startButton = nullptr;
HWND g_stopButton = nullptr;
HWND g_testButton = nullptr;
HWND g_counterLabel = nullptr;
HWND g_statusLabel = nullptr;
std::array<HWND, kSliderBindings.size()> g_sliders = {};
std::array<HWND, kSliderBindings.size()> g_valueLabels = {};

HFONT g_fontBody = nullptr;
HFONT g_fontSmall = nullptr;
HFONT g_fontHeading = nullptr;
HFONT g_fontTitle = nullptr;
HFONT g_fontMono = nullptr;
HBRUSH g_editBrush = nullptr;
HBRUSH g_backgroundBrush = nullptr;
HBRUSH g_staticPanelBrush = nullptr;
HBRUSH g_panelRaisedBrush = nullptr;
BackBuffer g_mainBackBuffer;

std::vector<VoiceInfo> g_voices;
std::atomic<bool> g_stopRequested = false;
std::atomic<bool> g_running = false;
std::atomic<int> g_playbackPositionMs = 0;
std::atomic<int> g_playbackLengthMs = 0;
HANDLE g_workerThread = nullptr;
std::atomic<bool> g_workerCompleted = false;
std::atomic<HRESULT> g_workerResult = E_FAIL;
bool g_closeAfterStop = false;
bool g_applyingPreset = false;
bool g_mechanicalEnabled = true;
bool g_binaryEnabled = true;
UINT g_dpi = 96;
double g_logoAngle = 0.0;
uint32_t g_binaryAnimation = 0x4D414749u;

int Scale(int value) {
    return MulDiv(value, static_cast<int>(g_dpi), 96);
}

RECT CalculateWindowBounds(
    UINT layoutDpi,
    UINT frameDpi,
    DWORD style,
    DWORD extendedStyle) {
    RECT bounds = {
        0,
        0,
        MulDiv(kClientWidth, static_cast<int>(layoutDpi), 96),
        MulDiv(kClientHeight, static_cast<int>(layoutDpi), 96)};
    if (!AdjustWindowRectExForDpi(
            &bounds,
            style,
            FALSE,
            extendedStyle,
            frameDpi)) {
        AdjustWindowRectEx(
            &bounds,
            style,
            FALSE,
            extendedStyle);
    }
    return bounds;
}

UINT ChooseLayoutDpi(
    const RECT& workArea,
    UINT requestedDpi,
    DWORD style,
    DWORD extendedStyle) {
    const int maximumWidth =
        std::max(1L, workArea.right - workArea.left - 24L);
    const int maximumHeight =
        std::max(1L, workArea.bottom - workArea.top - 24L);
    const int startDpi =
        static_cast<int>(std::max(requestedDpi, kMinimumLayoutDpi));

    for (int candidate = startDpi;
         candidate >= static_cast<int>(kMinimumLayoutDpi);
         --candidate) {
        const RECT bounds = CalculateWindowBounds(
            static_cast<UINT>(candidate),
            requestedDpi,
            style,
            extendedStyle);
        if (bounds.right - bounds.left <= maximumWidth &&
            bounds.bottom - bounds.top <= maximumHeight) {
            return static_cast<UINT>(candidate);
        }
    }
    return kMinimumLayoutDpi;
}

void SetControlFont(HWND control, HFONT font) {
    SendMessageW(control, WM_SETFONT, reinterpret_cast<WPARAM>(font), TRUE);
}

HFONT CreateInterfaceFont(
    int pointSize,
    int weight,
    const wchar_t* face,
    bool italic = false) {
    const int height = -MulDiv(pointSize, static_cast<int>(g_dpi), 72);
    return CreateFontW(
        height,
        0,
        0,
        0,
        weight,
        italic ? TRUE : FALSE,
        FALSE,
        FALSE,
        DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY,
        DEFAULT_PITCH | FF_DONTCARE,
        face);
}

void DrawFilledRoundRect(
    HDC device,
    const RECT& bounds,
    int radius,
    COLORREF fill,
    COLORREF outline,
    int outlineWidth = 1) {
    HBRUSH brush = CreateSolidBrush(fill);
    HPEN pen = CreatePen(PS_SOLID, std::max(1, outlineWidth), outline);
    HGDIOBJ oldBrush = SelectObject(device, brush);
    HGDIOBJ oldPen = SelectObject(device, pen);
    RoundRect(
        device,
        bounds.left,
        bounds.top,
        bounds.right,
        bounds.bottom,
        radius,
        radius);
    SelectObject(device, oldPen);
    SelectObject(device, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

void DrawMechanicusEmblem(HDC device, int centerX, int centerY, int radius) {
    const int saved = SaveDC(device);
    SetGraphicsMode(device, GM_ADVANCED);

    std::vector<POINT> gearPoints;
    constexpr int teeth = 16;
    gearPoints.reserve(teeth * 4);
    for (int index = 0; index < teeth * 4; ++index) {
        const int section = index % 4;
        const double toothRadius =
            section == 0 || section == 3
                ? radius * 1.10
                : radius * 0.88;
        const double angle =
            g_logoAngle +
            index * (2.0 * 3.14159265358979323846 / (teeth * 4));
        gearPoints.push_back({
            centerX + static_cast<LONG>(std::cos(angle) * toothRadius),
            centerY + static_cast<LONG>(std::sin(angle) * toothRadius)});
    }

    HBRUSH crimsonBrush = CreateSolidBrush(kCrimson);
    HPEN gearPen = CreatePen(PS_SOLID, std::max(1, radius / 18), kCrimsonBright);
    HGDIOBJ oldBrush = SelectObject(device, crimsonBrush);
    HGDIOBJ oldPen = SelectObject(device, gearPen);
    Polygon(device, gearPoints.data(), static_cast<int>(gearPoints.size()));

    HBRUSH darkBrush = CreateSolidBrush(kBackground);
    SelectObject(device, darkBrush);
    Ellipse(
        device,
        centerX - static_cast<int>(radius * 0.72),
        centerY - static_cast<int>(radius * 0.72),
        centerX + static_cast<int>(radius * 0.72),
        centerY + static_cast<int>(radius * 0.72));

    const RECT skullHead = {
        centerX - static_cast<int>(radius * 0.39),
        centerY - static_cast<int>(radius * 0.45),
        centerX + static_cast<int>(radius * 0.39),
        centerY + static_cast<int>(radius * 0.27)};
    const RECT jaw = {
        centerX - static_cast<int>(radius * 0.25),
        centerY + static_cast<int>(radius * 0.07),
        centerX + static_cast<int>(radius * 0.25),
        centerY + static_cast<int>(radius * 0.51)};

    HPEN skullPen = CreatePen(PS_SOLID, std::max(1, radius / 24), RGB(8, 8, 9));
    SelectObject(device, skullPen);

    const int skullSaved = SaveDC(device);
    IntersectClipRect(
        device,
        centerX - radius,
        centerY - radius,
        centerX,
        centerY + radius);
    HBRUSH boneBrush = CreateSolidBrush(kBone);
    SelectObject(device, boneBrush);
    Ellipse(
        device,
        skullHead.left,
        skullHead.top,
        skullHead.right,
        skullHead.bottom);
    RoundRect(
        device,
        jaw.left,
        jaw.top,
        jaw.right,
        jaw.bottom,
        radius / 5,
        radius / 5);
    RestoreDC(device, skullSaved);

    const int metalSaved = SaveDC(device);
    IntersectClipRect(
        device,
        centerX,
        centerY - radius,
        centerX + radius,
        centerY + radius);
    HBRUSH steelBrush = CreateSolidBrush(kSteel);
    SelectObject(device, steelBrush);
    Ellipse(
        device,
        skullHead.left,
        skullHead.top,
        skullHead.right,
        skullHead.bottom);
    RoundRect(
        device,
        jaw.left,
        jaw.top,
        jaw.right,
        jaw.bottom,
        radius / 5,
        radius / 5);
    RestoreDC(device, metalSaved);

    HBRUSH socketBrush = CreateSolidBrush(RGB(5, 5, 6));
    SelectObject(device, socketBrush);
    const int eyeRadius = std::max(2, radius / 9);
    Ellipse(
        device,
        centerX - radius / 4 - eyeRadius,
        centerY - radius / 10 - eyeRadius,
        centerX - radius / 4 + eyeRadius,
        centerY - radius / 10 + eyeRadius);
    Ellipse(
        device,
        centerX + radius / 4 - eyeRadius,
        centerY - radius / 10 - eyeRadius,
        centerX + radius / 4 + eyeRadius,
        centerY - radius / 10 + eyeRadius);

    HBRUSH eyeBrush = CreateSolidBrush(kCrimsonBright);
    SelectObject(device, eyeBrush);
    const int eyeGlow = std::max(2, radius / 15);
    Ellipse(
        device,
        centerX + radius / 4 - eyeGlow,
        centerY - radius / 10 - eyeGlow,
        centerX + radius / 4 + eyeGlow,
        centerY - radius / 10 + eyeGlow);

    POINT nose[3] = {
        {centerX, centerY},
        {centerX - radius / 10, centerY + radius / 13},
        {centerX + radius / 10, centerY + radius / 13}};
    SelectObject(device, socketBrush);
    Polygon(device, nose, 3);

    HPEN detailPen = CreatePen(PS_SOLID, std::max(1, radius / 34), RGB(45, 47, 50));
    SelectObject(device, detailPen);
    MoveToEx(device, centerX, skullHead.top + radius / 10, nullptr);
    LineTo(device, centerX, jaw.bottom);
    for (int tooth = -2; tooth <= 2; ++tooth) {
        const int x = centerX + tooth * radius / 11;
        MoveToEx(device, x, centerY + radius / 5, nullptr);
        LineTo(device, x, jaw.bottom - radius / 18);
    }
    MoveToEx(
        device,
        centerX + radius / 4,
        centerY + radius / 22,
        nullptr);
    LineTo(
        device,
        centerX + radius / 2,
        centerY + radius / 3);
    LineTo(
        device,
        centerX + radius / 2,
        centerY + radius / 2);

    SelectObject(device, oldPen);
    SelectObject(device, oldBrush);
    DeleteObject(detailPen);
    DeleteObject(eyeBrush);
    DeleteObject(socketBrush);
    DeleteObject(steelBrush);
    DeleteObject(boneBrush);
    DeleteObject(skullPen);
    DeleteObject(darkBrush);
    DeleteObject(gearPen);
    DeleteObject(crimsonBrush);
    RestoreDC(device, saved);
}

void DrawBinaryHeader(HDC device, const RECT& client) {
    wchar_t binary[45] = {};
    uint32_t value = g_binaryAnimation;
    for (int index = 0; index < 44; ++index) {
        value ^= value << 13;
        value ^= value >> 17;
        value ^= value << 5;
        binary[index] = (value & 1u) ? L'1' : L'0';
    }

    HFONT oldFont = static_cast<HFONT>(SelectObject(device, g_fontMono));
    SetBkMode(device, TRANSPARENT);
    SetTextColor(device, RGB(61, 102, 70));
    RECT binaryRect = {
        client.right - Scale(410),
        Scale(28),
        client.right - Scale(25),
        Scale(52)};
    DrawTextW(
        device,
        binary,
        -1,
        &binaryRect,
        DT_RIGHT | DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS);

    SetTextColor(device, kMutedText);
    RECT subRect = {
        client.right - Scale(410),
        Scale(57),
        client.right - Scale(25),
        Scale(82)};
    DrawTextW(
        device,
        L"СИСТЕМА ВОКС-ЛИТУРГИИ  //  КОНТУР 4.0",
        -1,
        &subRect,
        DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
    SelectObject(device, oldFont);
}

SliderState* GetSliderState(HWND slider) {
    return reinterpret_cast<SliderState*>(
        GetWindowLongPtrW(slider, GWLP_USERDATA));
}

int SliderValueFromPoint(HWND slider, int x) {
    SliderState* state = GetSliderState(slider);
    if (!state) {
        return 0;
    }
    RECT client = {};
    GetClientRect(slider, &client);
    const int padding = Scale(9);
    const int width = std::max(
        1,
        static_cast<int>(client.right - client.left) - padding * 2);
    const int clamped = std::clamp(x - padding, 0, width);
    const double ratio = clamped / static_cast<double>(width);
    return state->minimum +
           static_cast<int>(
               std::round((state->maximum - state->minimum) * ratio));
}

void NotifySliderChanged(HWND slider) {
    SliderState* state = GetSliderState(slider);
    if (!state) {
        return;
    }
    SendMessageW(
        GetParent(slider),
        WM_HSCROLL,
        MAKEWPARAM(SB_THUMBTRACK, state->value),
        reinterpret_cast<LPARAM>(slider));
}

LRESULT CALLBACK SliderWindowProc(
    HWND window,
    UINT message,
    WPARAM wParam,
    LPARAM lParam) {
    SliderState* state = GetSliderState(window);
    switch (message) {
        case WM_NCCREATE: {
            const CREATESTRUCTW* create =
                reinterpret_cast<CREATESTRUCTW*>(lParam);
            const SliderState* initial =
                static_cast<const SliderState*>(create->lpCreateParams);
            auto* allocated =
                initial
                    ? new (std::nothrow) SliderState(*initial)
                    : nullptr;
            if (!allocated) {
                return FALSE;
            }
            SetWindowLongPtrW(
                window,
                GWLP_USERDATA,
                reinterpret_cast<LONG_PTR>(allocated));
            return TRUE;
        }
        case WM_NCDESTROY:
            delete state;
            SetWindowLongPtrW(window, GWLP_USERDATA, 0);
            return 0;
        case WM_ERASEBKGND:
            return 1;
        case WM_PAINT: {
            PAINTSTRUCT paint = {};
            HDC screenDevice = BeginPaint(window, &paint);
            RECT client = {};
            GetClientRect(window, &client);
            HDC memoryDevice = CreateCompatibleDC(screenDevice);
            HBITMAP bitmap =
                memoryDevice
                    ? CreateCompatibleBitmap(
                          screenDevice,
                          std::max<LONG>(1, client.right),
                          std::max<LONG>(1, client.bottom))
                    : nullptr;
            HGDIOBJ previousBitmap =
                bitmap
                    ? SelectObject(memoryDevice, bitmap)
                    : nullptr;
            HDC device =
                memoryDevice && bitmap &&
                        previousBitmap &&
                        previousBitmap != HGDI_ERROR
                    ? memoryDevice
                    : screenDevice;
            HBRUSH background = CreateSolidBrush(kPanel);
            FillRect(device, &client, background);
            DeleteObject(background);

            if (state) {
                const bool enabled = IsWindowEnabled(window) != FALSE;
                const int padding = Scale(9);
                const int centerY = (client.bottom - client.top) / 2;
                RECT track = {
                    padding,
                    centerY - Scale(3),
                    client.right - padding,
                    centerY + Scale(3)};
                DrawFilledRoundRect(
                    device,
                    track,
                    Scale(6),
                    enabled ? RGB(54, 54, 60) : RGB(39, 39, 43),
                    enabled ? RGB(54, 54, 60) : RGB(39, 39, 43));

                const double ratio =
                    (state->value - state->minimum) /
                    static_cast<double>(
                        std::max(1, state->maximum - state->minimum));
                const int thumbX =
                    padding +
                    static_cast<int>(
                        ratio * (client.right - padding * 2));
                RECT active = track;
                active.right = std::max<LONG>(
                    active.left + 1,
                    static_cast<LONG>(thumbX));
                DrawFilledRoundRect(
                    device,
                    active,
                    Scale(6),
                    enabled ? kCrimson : RGB(73, 53, 56),
                    enabled ? kCrimson : RGB(73, 53, 56));

                HBRUSH glow = CreateSolidBrush(
                    enabled ? kCrimsonBright : RGB(92, 82, 83));
                HPEN pen = CreatePen(
                    PS_SOLID,
                    std::max(1, Scale(2)),
                    enabled ? kBone : RGB(128, 124, 118));
                HGDIOBJ oldBrush = SelectObject(device, glow);
                HGDIOBJ oldPen = SelectObject(device, pen);
                Ellipse(
                    device,
                    thumbX - Scale(7),
                    centerY - Scale(7),
                    thumbX + Scale(7),
                    centerY + Scale(7));
                SelectObject(device, oldPen);
                SelectObject(device, oldBrush);
                DeleteObject(pen);
                DeleteObject(glow);
            }

            if (device == memoryDevice) {
                BitBlt(
                    screenDevice,
                    paint.rcPaint.left,
                    paint.rcPaint.top,
                    paint.rcPaint.right - paint.rcPaint.left,
                    paint.rcPaint.bottom - paint.rcPaint.top,
                    memoryDevice,
                    paint.rcPaint.left,
                    paint.rcPaint.top,
                    SRCCOPY);
            }
            if (memoryDevice && previousBitmap &&
                previousBitmap != HGDI_ERROR) {
                SelectObject(memoryDevice, previousBitmap);
            }
            if (bitmap) {
                DeleteObject(bitmap);
            }
            if (memoryDevice) {
                DeleteDC(memoryDevice);
            }
            EndPaint(window, &paint);
            return 0;
        }
        case WM_ENABLE:
            InvalidateRect(window, nullptr, FALSE);
            return 0;
        case WM_LBUTTONDOWN:
            if (state) {
                SetFocus(window);
                SetCapture(window);
                state->dragging = true;
                state->value = std::clamp(
                    SliderValueFromPoint(window, GET_X_LPARAM(lParam)),
                    state->minimum,
                    state->maximum);
                InvalidateRect(window, nullptr, FALSE);
                NotifySliderChanged(window);
            }
            return 0;
        case WM_MOUSEMOVE:
            if (state && state->dragging) {
                const int next = std::clamp(
                    SliderValueFromPoint(window, GET_X_LPARAM(lParam)),
                    state->minimum,
                    state->maximum);
                if (next != state->value) {
                    state->value = next;
                    InvalidateRect(window, nullptr, FALSE);
                    NotifySliderChanged(window);
                }
            }
            return 0;
        case WM_LBUTTONUP:
            if (state && state->dragging) {
                state->dragging = false;
                ReleaseCapture();
                NotifySliderChanged(window);
            }
            return 0;
        case WM_KEYDOWN:
            if (state) {
                int delta = 0;
                if (wParam == VK_LEFT || wParam == VK_DOWN) {
                    delta = -1;
                } else if (wParam == VK_RIGHT || wParam == VK_UP) {
                    delta = 1;
                } else if (wParam == VK_PRIOR) {
                    delta = 5;
                } else if (wParam == VK_NEXT) {
                    delta = -5;
                } else if (wParam == VK_HOME) {
                    state->value = state->minimum;
                } else if (wParam == VK_END) {
                    state->value = state->maximum;
                } else {
                    break;
                }
                state->value =
                    std::clamp(
                        state->value + delta,
                        state->minimum,
                        state->maximum);
                InvalidateRect(window, nullptr, FALSE);
                NotifySliderChanged(window);
            }
            return 0;
    }
    return DefWindowProcW(window, message, wParam, lParam);
}

HWND CreateMagosSlider(
    HWND parent,
    int id,
    int x,
    int y,
    int width,
    int height,
    int minimum,
    int maximum,
    int value) {
    SliderState initial = {minimum, maximum, value, false};
    return CreateWindowExW(
        0,
        kSliderWindowClass,
        nullptr,
        WS_CHILD | WS_VISIBLE | WS_TABSTOP,
        Scale(x),
        Scale(y),
        Scale(width),
        Scale(height),
        parent,
        reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
        g_instance,
        &initial);
}

int GetSliderValue(HWND slider) {
    SliderState* state = GetSliderState(slider);
    return state ? state->value : 0;
}

void SetSliderValue(HWND slider, int value) {
    SliderState* state = GetSliderState(slider);
    if (!state) {
        return;
    }
    state->value = std::clamp(value, state->minimum, state->maximum);
    InvalidateRect(slider, nullptr, FALSE);
}

HWND CreateLabel(
    HWND parent,
    int id,
    const wchar_t* text,
    int x,
    int y,
    int width,
    int height,
    HFONT font,
    DWORD alignment = SS_LEFT) {
    HWND label = CreateWindowExW(
        0,
        L"STATIC",
        text,
        WS_CHILD | WS_VISIBLE | alignment,
        Scale(x),
        Scale(y),
        Scale(width),
        Scale(height),
        parent,
        reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
        g_instance,
        nullptr);
    SetControlFont(label, font);
    return label;
}

HWND CreateOwnerButton(
    HWND parent,
    int id,
    const wchar_t* text,
    int x,
    int y,
    int width,
    int height,
    DWORD extraStyle = 0) {
    HWND button = CreateWindowExW(
        0,
        L"BUTTON",
        text,
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_OWNERDRAW | extraStyle,
        Scale(x),
        Scale(y),
        Scale(width),
        Scale(height),
        parent,
        reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
        g_instance,
        nullptr);
    SetControlFont(button, g_fontBody);
    return button;
}

void UpdateSliderValueLabel(size_t index) {
    if (index >= g_sliders.size()) {
        return;
    }
    const int value = GetSliderValue(g_sliders[index]);
    wchar_t text[24] = {};
    const int sliderId = kSliderBindings[index].sliderId;
    if (sliderId == IDC_SLIDER_RATE ||
        sliderId == IDC_SLIDER_TIMBRE) {
        swprintf_s(text, L"%+d", value);
    } else {
        swprintf_s(text, L"%d%%", value);
    }
    SetWindowTextW(g_valueLabels[index], text);
}

void UpdateAllSliderLabels() {
    for (size_t index = 0; index < g_sliders.size(); ++index) {
        UpdateSliderValueLabel(index);
    }
}

void RefreshControlAvailability() {
    const bool running = g_running.load();
    const BOOL idleEnabled = running ? FALSE : TRUE;

    if (g_litanyEdit) {
        SendMessageW(
            g_litanyEdit,
            EM_SETREADONLY,
            running ? TRUE : FALSE,
            0);
    }
    if (g_voiceCombo) {
        EnableWindow(g_voiceCombo, idleEnabled);
    }
    if (g_presetCombo) {
        EnableWindow(g_presetCombo, idleEnabled);
    }
    if (g_mechanicalCheck) {
        EnableWindow(g_mechanicalCheck, idleEnabled);
    }
    if (g_binaryCheck) {
        EnableWindow(g_binaryCheck, idleEnabled);
    }
    if (g_openButton) {
        EnableWindow(g_openButton, idleEnabled);
    }
    if (g_saveButton) {
        EnableWindow(g_saveButton, TRUE);
    }
    if (g_startButton) {
        EnableWindow(g_startButton, idleEnabled);
    }
    if (g_testButton) {
        EnableWindow(g_testButton, idleEnabled);
    }
    if (g_stopButton) {
        EnableWindow(
            g_stopButton,
            running && !g_stopRequested.load());
    }

    for (size_t index = 0; index < g_sliders.size(); ++index) {
        bool enabled = !running;
        const int sliderId = kSliderBindings[index].sliderId;
        if (sliderId == IDC_SLIDER_MECHANICAL ||
            sliderId == IDC_SLIDER_DISTORTION ||
            sliderId == IDC_SLIDER_BITCRUSH ||
            sliderId == IDC_SLIDER_RESONANCE) {
            enabled = enabled && g_mechanicalEnabled;
        } else if (sliderId == IDC_SLIDER_BINARY) {
            enabled = enabled && g_binaryEnabled;
        }
        if (g_sliders[index]) {
            EnableWindow(g_sliders[index], enabled ? TRUE : FALSE);
        }
        if (g_valueLabels[index]) {
            EnableWindow(
                g_valueLabels[index],
                enabled ? TRUE : FALSE);
        }
    }

    if (g_mechanicalCheck) {
        InvalidateRect(g_mechanicalCheck, nullptr, FALSE);
    }
    if (g_binaryCheck) {
        InvalidateRect(g_binaryCheck, nullptr, FALSE);
    }
}

void SetPresetValues(
    int rate,
    int speech,
    int timbre,
    int mechanical,
    int distortion,
    int bitcrush,
    int resonance,
    int binary,
    int organ,
    int choir,
    bool mechanicalEnabled,
    bool binaryEnabled) {
    const std::array<int, 10> values = {
        rate,
        speech,
        timbre,
        mechanical,
        distortion,
        bitcrush,
        resonance,
        binary,
        organ,
        choir};
    for (size_t index = 0; index < values.size(); ++index) {
        SetSliderValue(g_sliders[index], values[index]);
    }
    g_mechanicalEnabled = mechanicalEnabled;
    g_binaryEnabled = binaryEnabled;
    UpdateAllSliderLabels();
    RefreshControlAvailability();
}

void ApplyPreset(int index) {
    if (index <= 0) {
        return;
    }
    g_applyingPreset = true;
    switch (index) {
        case 1:
            SetPresetValues(
                -1, 92, -2, 62, 34, 22, 56, 34, 34, 28, true, true);
            break;
        case 2:
            SetPresetValues(
                -2, 94, -4, 82, 54, 39, 79, 20, 22, 15, true, true);
            break;
        case 3:
            SetPresetValues(
                -1, 90, -2, 68, 36, 55, 46, 78, 27, 24, true, true);
            break;
        case 4:
            SetPresetValues(
                -3, 90, -5, 88, 62, 31, 90, 58, 50, 45, true, true);
            break;
        case 5:
            SetPresetValues(
                0, 100, 0, 0, 0, 0, 0, 0, 0, 0, false, false);
            break;
    }
    g_applyingPreset = false;
}

void MarkSettingsCustom() {
    if (!g_applyingPreset) {
        SendMessageW(g_presetCombo, CB_SETCURSEL, 0, 0);
    }
}

AudioSettings ReadAudioSettings() {
    AudioSettings settings;
    settings.speechRate = GetSliderValue(g_sliders[0]);
    settings.speechVolume = GetSliderValue(g_sliders[1]);
    settings.voiceTimbre = GetSliderValue(g_sliders[2]);
    settings.mechanical = GetSliderValue(g_sliders[3]);
    settings.distortion = GetSliderValue(g_sliders[4]);
    settings.bitcrush = GetSliderValue(g_sliders[5]);
    settings.resonance = GetSliderValue(g_sliders[6]);
    settings.binaryVolume = GetSliderValue(g_sliders[7]);
    settings.organVolume = GetSliderValue(g_sliders[8]);
    settings.choirVolume = GetSliderValue(g_sliders[9]);
    settings.mechanicalEnabled = g_mechanicalEnabled;
    settings.binaryEnabled = g_binaryEnabled;
    return settings;
}

std::wstring GetWindowTextString(HWND control) {
    const int length = GetWindowTextLengthW(control);
    std::wstring text(static_cast<size_t>(length) + 1, L'\0');
    if (length > 0) {
        GetWindowTextW(control, text.data(), length + 1);
    }
    text.resize(static_cast<size_t>(length));
    return text;
}

bool HasVisibleText(const std::wstring& text) {
    return std::any_of(
        text.begin(),
        text.end(),
        [](wchar_t character) {
            return !iswspace(character);
        });
}

void UpdateCharacterCounter() {
    const int characters = GetWindowTextLengthW(g_litanyEdit);
    wchar_t text[48] = {};
    swprintf_s(
        text,
        L"СИМВОЛОВ: %d",
        characters);
    SetWindowTextW(g_counterLabel, text);
}

std::wstring FormatClock(int milliseconds) {
    const int totalSeconds = std::max(0, milliseconds / 1000);
    wchar_t text[16] = {};
    swprintf_s(
        text,
        L"%02d:%02d",
        totalSeconds / 60,
        totalSeconds % 60);
    return text;
}

void SetStatusText(const std::wstring& text) {
    SetWindowTextW(g_statusLabel, text.c_str());
}

std::wstring DescribeError(HRESULT result) {
    const std::wstring audioDescription =
        DescribeAudioResult(result);
    if (!audioDescription.empty()) {
        return audioDescription;
    }

    wchar_t* message = nullptr;
    const DWORD flags =
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS;
    FormatMessageW(
        flags,
        nullptr,
        static_cast<DWORD>(result),
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        reinterpret_cast<wchar_t*>(&message),
        0,
        nullptr);
    std::wstring description =
        message ? message : L"Неизвестная ошибка голосового контура.";
    if (message) {
        LocalFree(message);
    }
    while (!description.empty() &&
           (description.back() == L'\r' ||
            description.back() == L'\n' ||
            description.back() == L' ')) {
        description.pop_back();
    }
    return description;
}

struct RitualWorkerContext {
    RitualRequest request;
    HWND targetWindow = nullptr;
};

unsigned __stdcall RitualWorkerProc(void* parameter) {
    std::unique_ptr<RitualWorkerContext> context(
        static_cast<RitualWorkerContext*>(parameter));
    const HWND targetWindow =
        context ? context->targetWindow : nullptr;
    const auto statusCallback =
        [targetWindow](RitualStage stage) noexcept {
            if (targetWindow) {
                PostMessageW(
                    targetWindow,
                    WM_MAGOS_STATUS,
                    static_cast<WPARAM>(stage),
                    0);
            }
    };

    HRESULT result = E_UNEXPECTED;
    try {
        if (context) {
            result = RunRitualAudio(
                context->request,
                g_stopRequested,
                g_playbackPositionMs,
                g_playbackLengthMs,
                statusCallback);
        }
    } catch (const std::bad_alloc&) {
        result = E_OUTOFMEMORY;
    } catch (...) {
        result = E_UNEXPECTED;
    }

    g_workerResult.store(result, std::memory_order_relaxed);
    g_workerCompleted.store(true, std::memory_order_release);
    if (targetWindow) {
        PostMessageW(targetWindow, WM_MAGOS_FINISHED, 0, 0);
    }
    return 0;
}

void BeginRitual(const std::wstring* overrideText = nullptr) {
    if (g_running.load()) {
        MessageBeep(MB_ICONWARNING);
        return;
    }

    try {
        std::wstring text =
            overrideText ? *overrideText : GetWindowTextString(g_litanyEdit);
        if (!HasVisibleText(text)) {
            MessageBoxW(
                g_mainWindow,
                L"Сначала впишите литанию. Даже Омниссия не озвучивает пустоту без технического задания.",
                L"Литания отсутствует",
                MB_OK | MB_ICONINFORMATION);
            SetFocus(g_litanyEdit);
            return;
        }

        auto context = std::make_unique<RitualWorkerContext>();
        context->request.text = std::move(text);
        context->request.settings = ReadAudioSettings();
        context->targetWindow = g_mainWindow;

        const int voiceIndex =
            static_cast<int>(
                SendMessageW(g_voiceCombo, CB_GETCURSEL, 0, 0));
        if (voiceIndex >= 0 &&
            voiceIndex < static_cast<int>(g_voices.size())) {
            context->request.voiceTokenId = g_voices[voiceIndex].id;
        }

        g_stopRequested.store(false);
        g_workerCompleted.store(false, std::memory_order_relaxed);
        g_workerResult.store(E_FAIL, std::memory_order_relaxed);
        g_playbackPositionMs.store(0);
        g_playbackLengthMs.store(0);
        g_closeAfterStop = false;
        g_running.store(true);
        RefreshControlAvailability();
        SetStatusText(L"ИНИЦИАЛИЗАЦИЯ РИТУАЛА...");
        InvalidateRect(g_mainWindow, nullptr, FALSE);

        RitualWorkerContext* rawContext = context.release();
        const uintptr_t threadHandle = _beginthreadex(
            nullptr,
            0,
            RitualWorkerProc,
            rawContext,
            0,
            nullptr);
        g_workerThread =
            reinterpret_cast<HANDLE>(threadHandle);
        if (!g_workerThread) {
            delete rawContext;
            g_running.store(false);
            RefreshControlAvailability();
            SetStatusText(
                L"ОШИБКА: НЕ УДАЛОСЬ СОЗДАТЬ ГОЛОСОВОЙ КОНТУР");
            MessageBoxW(
                g_mainWindow,
                L"Windows не удалось создать безопасный фоновый поток "
                L"для синтеза речи.",
                L"Ошибка запуска",
                MB_OK | MB_ICONERROR);
        }
    } catch (const std::bad_alloc&) {
        g_running.store(false);
        RefreshControlAvailability();
        SetStatusText(L"НЕДОСТАТОЧНО ПАМЯТИ ДЛЯ ЗАПУСКА РИТУАЛА");
        MessageBoxW(
            g_mainWindow,
            L"Windows не удалось выделить память для этой литании. "
            L"Разделите текст на несколько частей и повторите обряд.",
            L"Недостаточно памяти",
            MB_OK | MB_ICONERROR);
    }
}

void StopRitual() {
    if (!g_running.load()) {
        return;
    }
    g_stopRequested.store(true);
    RefreshControlAvailability();
    SetStatusText(L"ПРЕРЫВАНИЕ РИТУАЛА. ЗАКРЫТИЕ ВОКС-КАНАЛА...");
}

bool ReadWholeFile(const std::wstring& path, std::vector<uint8_t>& bytes) {
    HANDLE file = CreateFileW(
        path.c_str(),
        GENERIC_READ,
        FILE_SHARE_READ,
        nullptr,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        nullptr);
    if (file == INVALID_HANDLE_VALUE) {
        return false;
    }

    LARGE_INTEGER size = {};
    if (!GetFileSizeEx(file, &size) ||
        size.QuadPart < 0 ||
        size.QuadPart > kMaxLitanyFileBytes) {
        CloseHandle(file);
        SetLastError(ERROR_FILE_TOO_LARGE);
        return false;
    }

    bytes.resize(static_cast<size_t>(size.QuadPart));
    size_t totalRead = 0;
    bool success = true;
    while (totalRead < bytes.size()) {
        const DWORD requested = static_cast<DWORD>(
            std::min<size_t>(
                bytes.size() - totalRead,
                std::numeric_limits<DWORD>::max()));
        DWORD read = 0;
        if (!ReadFile(
                file,
                bytes.data() + totalRead,
                requested,
                &read,
                nullptr)) {
            success = false;
            break;
        }
        if (read == 0) {
            SetLastError(ERROR_HANDLE_EOF);
            success = false;
            break;
        }
        totalRead += read;
    }
    CloseHandle(file);
    return success;
}

std::wstring DecodeUtf16(
    const std::vector<uint8_t>& bytes,
    size_t offset,
    bool bigEndian) {
    const size_t characterCount = (bytes.size() - offset) / 2;
    std::wstring result;
    result.reserve(characterCount);
    for (size_t index = 0; index < characterCount; ++index) {
        const uint8_t first = bytes[offset + index * 2];
        const uint8_t second = bytes[offset + index * 2 + 1];
        const uint16_t value =
            bigEndian
                ? static_cast<uint16_t>(
                      (static_cast<uint16_t>(first) << 8) | second)
                : static_cast<uint16_t>(
                      first | (static_cast<uint16_t>(second) << 8));
        result.push_back(static_cast<wchar_t>(value));
    }
    return result;
}

void SanitizeDecodedText(std::wstring& text) {
    for (wchar_t& character : text) {
        if (character == L'\0') {
            character = L' ';
        }
    }
}

std::wstring DecodeTextFile(const std::vector<uint8_t>& bytes) {
    if (bytes.empty()) {
        return {};
    }

    if (bytes.size() >= 2 &&
        bytes[0] == 0xFF &&
        bytes[1] == 0xFE) {
        std::wstring result = DecodeUtf16(bytes, 2, false);
        SanitizeDecodedText(result);
        return result;
    }
    if (bytes.size() >= 2 &&
        bytes[0] == 0xFE &&
        bytes[1] == 0xFF) {
        std::wstring result = DecodeUtf16(bytes, 2, true);
        SanitizeDecodedText(result);
        return result;
    }

    size_t offset = 0;
    if (bytes.size() >= 3 &&
        bytes[0] == 0xEF &&
        bytes[1] == 0xBB &&
        bytes[2] == 0xBF) {
        offset = 3;
    }

    const char* source =
        reinterpret_cast<const char*>(bytes.data() + offset);
    const int sourceLength = static_cast<int>(bytes.size() - offset);
    int characterCount = MultiByteToWideChar(
        CP_UTF8,
        MB_ERR_INVALID_CHARS,
        source,
        sourceLength,
        nullptr,
        0);
    UINT codePage = CP_UTF8;
    DWORD flags = MB_ERR_INVALID_CHARS;
    if (characterCount <= 0) {
        codePage = CP_ACP;
        flags = 0;
        characterCount = MultiByteToWideChar(
            codePage,
            flags,
            source,
            sourceLength,
            nullptr,
            0);
    }
    std::wstring result(
        static_cast<size_t>(std::max(0, characterCount)),
        L'\0');
    if (characterCount > 0) {
        MultiByteToWideChar(
            codePage,
            flags,
            source,
            sourceLength,
            result.data(),
            characterCount);
    }
    SanitizeDecodedText(result);
    return result;
}

bool WriteUtf8File(const std::wstring& path, const std::wstring& text) {
    if (text.size() >
        static_cast<size_t>(std::numeric_limits<int>::max())) {
        SetLastError(ERROR_FILE_TOO_LARGE);
        return false;
    }
    const int byteCount = WideCharToMultiByte(
        CP_UTF8,
        WC_ERR_INVALID_CHARS,
        text.c_str(),
        static_cast<int>(text.size()),
        nullptr,
        0,
        nullptr,
        nullptr);
    if (byteCount <= 0 && !text.empty()) {
        return false;
    }
    std::vector<uint8_t> bytes = {0xEF, 0xBB, 0xBF};
    const size_t offset = bytes.size();
    bytes.resize(offset + static_cast<size_t>(std::max(0, byteCount)));
    if (byteCount > 0) {
        const int converted = WideCharToMultiByte(
            CP_UTF8,
            WC_ERR_INVALID_CHARS,
            text.c_str(),
            static_cast<int>(text.size()),
            reinterpret_cast<char*>(bytes.data() + offset),
            byteCount,
            nullptr,
            nullptr);
        if (converted != byteCount) {
            return false;
        }
    }

    const std::wstring temporaryPath =
        path + L".pocketmagos.tmp";
    HANDLE file = CreateFileW(
        temporaryPath.c_str(),
        GENERIC_WRITE,
        0,
        nullptr,
        CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        nullptr);
    if (file == INVALID_HANDLE_VALUE) {
        return false;
    }
    size_t totalWritten = 0;
    bool success = true;
    while (totalWritten < bytes.size()) {
        const DWORD requested = static_cast<DWORD>(
            std::min<size_t>(
                bytes.size() - totalWritten,
                std::numeric_limits<DWORD>::max()));
        DWORD written = 0;
        if (!WriteFile(
                file,
                bytes.data() + totalWritten,
                requested,
                &written,
                nullptr)) {
            success = false;
            break;
        }
        if (written == 0) {
            SetLastError(ERROR_WRITE_FAULT);
            success = false;
            break;
        }
        totalWritten += written;
    }
    if (success && !FlushFileBuffers(file)) {
        success = false;
    }
    const DWORD writeError =
        success ? ERROR_SUCCESS : GetLastError();
    CloseHandle(file);

    if (!success) {
        DeleteFileW(temporaryPath.c_str());
        SetLastError(writeError);
        return false;
    }

    if (!MoveFileExW(
            temporaryPath.c_str(),
            path.c_str(),
            MOVEFILE_REPLACE_EXISTING |
                MOVEFILE_WRITE_THROUGH)) {
        const DWORD moveError = GetLastError();
        DeleteFileW(temporaryPath.c_str());
        SetLastError(moveError);
        return false;
    }
    return true;
}

void OpenLitanyImpl() {
    std::array<wchar_t, 32768> path = {};
    OPENFILENAMEW dialog = {};
    dialog.lStructSize = sizeof(dialog);
    dialog.hwndOwner = g_mainWindow;
    dialog.lpstrFilter =
        L"Текстовые литании (*.txt)\0*.txt\0"
        L"Все файлы (*.*)\0*.*\0\0";
    dialog.lpstrFile = path.data();
    dialog.nMaxFile = static_cast<DWORD>(path.size());
    dialog.Flags =
        OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST |
        OFN_EXPLORER | OFN_NOCHANGEDIR;
    dialog.lpstrDefExt = L"txt";

    if (!GetOpenFileNameW(&dialog)) {
        return;
    }

    std::vector<uint8_t> bytes;
    if (!ReadWholeFile(path.data(), bytes)) {
        MessageBoxW(
            g_mainWindow,
            DescribeError(HRESULT_FROM_WIN32(GetLastError())).c_str(),
            L"Не удалось открыть литанию",
            MB_OK | MB_ICONERROR);
        return;
    }
    const std::wstring text = DecodeTextFile(bytes);
    if (text.size() > kMaxEditorCharacters) {
        MessageBoxW(
            g_mainWindow,
            L"Текст содержит больше миллиона символов. "
            L"Разделите литанию на несколько файлов.",
            L"Литания слишком велика",
            MB_OK | MB_ICONWARNING);
        return;
    }
    SetWindowTextW(g_litanyEdit, text.c_str());
    SetStatusText(L"ЛИТАНИЯ ЗАГРУЖЕНА В ОПЕРАТИВНУЮ ПАМЯТЬ");
}

void OpenLitany() {
    try {
        OpenLitanyImpl();
    } catch (const std::bad_alloc&) {
        MessageBoxW(
            g_mainWindow,
            L"Для загрузки этого текста недостаточно памяти.",
            L"Не удалось открыть литанию",
            MB_OK | MB_ICONERROR);
    } catch (...) {
        MessageBoxW(
            g_mainWindow,
            L"Windows вернула непредвиденную ошибку при чтении литании.",
            L"Не удалось открыть литанию",
            MB_OK | MB_ICONERROR);
    }
}

void SaveLitanyImpl() {
    std::array<wchar_t, 32768> path = {};
    wcscpy_s(
        path.data(),
        path.size(),
        L"Литания_Омниссии.txt");
    OPENFILENAMEW dialog = {};
    dialog.lStructSize = sizeof(dialog);
    dialog.hwndOwner = g_mainWindow;
    dialog.lpstrFilter =
        L"Текстовые литании (*.txt)\0*.txt\0"
        L"Все файлы (*.*)\0*.*\0\0";
    dialog.lpstrFile = path.data();
    dialog.nMaxFile = static_cast<DWORD>(path.size());
    dialog.Flags =
        OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST |
        OFN_EXPLORER | OFN_NOCHANGEDIR;
    dialog.lpstrDefExt = L"txt";

    if (!GetSaveFileNameW(&dialog)) {
        return;
    }
    if (!WriteUtf8File(
            path.data(),
            GetWindowTextString(g_litanyEdit))) {
        MessageBoxW(
            g_mainWindow,
            DescribeError(HRESULT_FROM_WIN32(GetLastError())).c_str(),
            L"Не удалось сохранить литанию",
            MB_OK | MB_ICONERROR);
        return;
    }
    SetStatusText(L"ЛИТАНИЯ СОХРАНЕНА В АРХИВЕ");
}

void SaveLitany() {
    try {
        SaveLitanyImpl();
    } catch (const std::bad_alloc&) {
        MessageBoxW(
            g_mainWindow,
            L"Для подготовки файла недостаточно памяти.",
            L"Не удалось сохранить литанию",
            MB_OK | MB_ICONERROR);
    } catch (...) {
        MessageBoxW(
            g_mainWindow,
            L"Windows вернула непредвиденную ошибку при сохранении литании.",
            L"Не удалось сохранить литанию",
            MB_OK | MB_ICONERROR);
    }
}

DWORD ReadRegistryDword(HKEY key, const wchar_t* name, DWORD fallback) {
    DWORD value = fallback;
    DWORD size = sizeof(value);
    DWORD type = 0;
    if (RegQueryValueExW(
            key,
            name,
            nullptr,
            &type,
            reinterpret_cast<BYTE*>(&value),
            &size) != ERROR_SUCCESS ||
        type != REG_DWORD) {
        return fallback;
    }
    return value;
}

std::wstring ReadRegistryString(HKEY key, const wchar_t* name) {
    DWORD type = 0;
    DWORD size = 0;
    if (RegQueryValueExW(
            key,
            name,
            nullptr,
            &type,
            nullptr,
            &size) != ERROR_SUCCESS ||
        type != REG_SZ ||
        size < sizeof(wchar_t) ||
        size > 64u * 1024u) {
        return {};
    }
    std::wstring value(size / sizeof(wchar_t), L'\0');
    if (RegQueryValueExW(
            key,
            name,
            nullptr,
            &type,
            reinterpret_cast<BYTE*>(value.data()),
            &size) != ERROR_SUCCESS) {
        return {};
    }
    while (!value.empty() && value.back() == L'\0') {
        value.pop_back();
    }
    return value;
}

bool LoadSettingsFromPath(
    const wchar_t* registryPath,
    bool legacySliderLayout) {
    RegistryKeyGuard key;
    if (RegOpenKeyExW(
            HKEY_CURRENT_USER,
            registryPath,
            0,
            KEY_READ,
            &key.key) != ERROR_SUCCESS) {
        return false;
    }

    for (size_t index = 0; index < g_sliders.size(); ++index) {
        SetSliderValue(g_sliders[index], kDefaultSliderValues[index]);
    }

    if (legacySliderLayout) {
        // Versions 3.0-3.2 stored nine sliders without a timbre field. Keep
        // their sound unchanged on migration and insert a neutral timbre at
        // the new third position.
        SetSliderValue(g_sliders[2], 0);
        for (size_t legacyIndex = 0;
             legacyIndex < kLegacySliderMapping.size();
             ++legacyIndex) {
            wchar_t name[32] = {};
            swprintf_s(
                name,
                L"Slider%u",
                static_cast<unsigned>(legacyIndex));
            const DWORD stored = ReadRegistryDword(
                key.key,
                name,
                static_cast<DWORD>(
                    kLegacyDefaultSliderValues[legacyIndex]));
            SetSliderValue(
                g_sliders[kLegacySliderMapping[legacyIndex]],
                static_cast<int>(stored));
        }
    } else {
        for (size_t index = 0; index < g_sliders.size(); ++index) {
            wchar_t name[32] = {};
            swprintf_s(name, L"Slider%u", static_cast<unsigned>(index));
            const DWORD stored = ReadRegistryDword(
                key.key,
                name,
                static_cast<DWORD>(kDefaultSliderValues[index]));
            SetSliderValue(g_sliders[index], static_cast<int>(stored));
        }
    }

    g_mechanicalEnabled =
        ReadRegistryDword(key.key, L"MechanicalEnabled", 1) != 0;
    g_binaryEnabled =
        ReadRegistryDword(key.key, L"BinaryEnabled", 1) != 0;
    SendMessageW(g_presetCombo, CB_SETCURSEL, 0, 0);

    const std::wstring preferredVoice =
        ReadRegistryString(key.key, L"VoiceTokenId");
    for (size_t index = 0; index < g_voices.size(); ++index) {
        if (g_voices[index].id == preferredVoice) {
            SendMessageW(
                g_voiceCombo,
                CB_SETCURSEL,
                static_cast<WPARAM>(index),
                0);
            break;
        }
    }
    UpdateAllSliderLabels();
    RefreshControlAvailability();
    return true;
}

void LoadSettings() {
    try {
        if (LoadSettingsFromPath(kRegistryPath, false) ||
            LoadSettingsFromPath(kLegacyRegistryPath32, true) ||
            LoadSettingsFromPath(kLegacyRegistryPath31, true) ||
            LoadSettingsFromPath(kLegacyRegistryPath30, true)) {
            return;
        }
    } catch (...) {
        // Corrupted or unexpectedly large profile data must not prevent the
        // application from starting with its known-good default protocol.
    }
    SendMessageW(g_presetCombo, CB_SETCURSEL, 1, 0);
    ApplyPreset(1);
}

void SaveSettings() {
    RegistryKeyGuard key;
    DWORD disposition = 0;
    if (RegCreateKeyExW(
            HKEY_CURRENT_USER,
            kRegistryPath,
            0,
            nullptr,
            0,
            KEY_WRITE,
            nullptr,
            &key.key,
            &disposition) != ERROR_SUCCESS) {
        return;
    }

    for (size_t index = 0; index < g_sliders.size(); ++index) {
        wchar_t name[32] = {};
        swprintf_s(name, L"Slider%u", static_cast<unsigned>(index));
        const DWORD value =
            static_cast<DWORD>(GetSliderValue(g_sliders[index]));
        RegSetValueExW(
            key.key,
            name,
            0,
            REG_DWORD,
            reinterpret_cast<const BYTE*>(&value),
            sizeof(value));
    }

    const DWORD mechanical = g_mechanicalEnabled ? 1u : 0u;
    const DWORD binary = g_binaryEnabled ? 1u : 0u;
    RegSetValueExW(
        key.key,
        L"MechanicalEnabled",
        0,
        REG_DWORD,
        reinterpret_cast<const BYTE*>(&mechanical),
        sizeof(mechanical));
    RegSetValueExW(
        key.key,
        L"BinaryEnabled",
        0,
        REG_DWORD,
        reinterpret_cast<const BYTE*>(&binary),
        sizeof(binary));

    const int voiceIndex =
        static_cast<int>(
            SendMessageW(g_voiceCombo, CB_GETCURSEL, 0, 0));
    if (voiceIndex >= 0 &&
        voiceIndex < static_cast<int>(g_voices.size())) {
        const std::wstring& id = g_voices[voiceIndex].id;
        RegSetValueExW(
            key.key,
            L"VoiceTokenId",
            0,
            REG_SZ,
            reinterpret_cast<const BYTE*>(id.c_str()),
            static_cast<DWORD>((id.size() + 1) * sizeof(wchar_t)));
    }
}

void DrawOwnerButton(const DRAWITEMSTRUCT* draw) {
    wchar_t text[256] = {};
    GetWindowTextW(draw->hwndItem, text, static_cast<int>(std::size(text)));
    const bool disabled = (draw->itemState & ODS_DISABLED) != 0;
    const bool pressed = (draw->itemState & ODS_SELECTED) != 0;
    const bool focused = (draw->itemState & ODS_FOCUS) != 0;
    const int id = static_cast<int>(draw->CtlID);

    if (id == IDC_MECHANICAL_CHECK || id == IDC_BINARY_CHECK) {
        HBRUSH background = CreateSolidBrush(kPanel);
        FillRect(draw->hDC, &draw->rcItem, background);
        DeleteObject(background);

        RECT box = draw->rcItem;
        box.left += Scale(2);
        box.top += Scale(4);
        box.right = box.left + Scale(18);
        box.bottom = box.top + Scale(18);
        const bool checked =
            id == IDC_MECHANICAL_CHECK
                ? g_mechanicalEnabled
                : g_binaryEnabled;
        DrawFilledRoundRect(
            draw->hDC,
            box,
            Scale(4),
            checked
                ? (disabled ? RGB(83, 44, 49) : kCrimson)
                : kPanelLight,
            checked
                ? (disabled ? RGB(112, 78, 82) : kCrimsonBright)
                : RGB(83, 83, 89),
            Scale(1));
        if (checked) {
            HPEN checkPen = CreatePen(
                PS_SOLID,
                std::max(1, Scale(2)),
                kBone);
            HGDIOBJ oldPen = SelectObject(draw->hDC, checkPen);
            MoveToEx(
                draw->hDC,
                box.left + Scale(4),
                box.top + Scale(9),
                nullptr);
            LineTo(
                draw->hDC,
                box.left + Scale(8),
                box.bottom - Scale(4));
            LineTo(
                draw->hDC,
                box.right - Scale(3),
                box.top + Scale(4));
            SelectObject(draw->hDC, oldPen);
            DeleteObject(checkPen);
        }

        RECT textRect = draw->rcItem;
        textRect.left += Scale(28);
        SetBkMode(draw->hDC, TRANSPARENT);
        SetTextColor(draw->hDC, disabled ? RGB(100, 100, 104) : kText);
        HFONT oldFont = static_cast<HFONT>(
            SelectObject(draw->hDC, g_fontSmall));
        DrawTextW(
            draw->hDC,
            text,
            -1,
            &textRect,
            DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        SelectObject(draw->hDC, oldFont);
        return;
    }

    COLORREF fill = kPanelRaised;
    COLORREF border = kCrimson;
    COLORREF foreground = kText;
    if (id == IDC_START_BUTTON) {
        fill = pressed ? RGB(91, 11, 21) : kCrimson;
        border = kCrimsonBright;
        foreground = kBone;
    } else if (id == IDC_STOP_BUTTON) {
        fill = pressed ? RGB(49, 49, 54) : RGB(35, 35, 40);
        border = RGB(115, 115, 122);
    } else if (pressed) {
        fill = kCrimsonDark;
        border = kCrimsonBright;
    }
    if (disabled) {
        fill = RGB(24, 24, 27);
        border = RGB(54, 54, 58);
        foreground = RGB(91, 91, 95);
    }

    const COLORREF surrounding =
        id == IDC_OPEN_BUTTON || id == IDC_SAVE_BUTTON
            ? kPanel
            : kBackground;
    HBRUSH surroundingBrush = CreateSolidBrush(surrounding);
    FillRect(draw->hDC, &draw->rcItem, surroundingBrush);
    DeleteObject(surroundingBrush);

    RECT bounds = draw->rcItem;
    InflateRect(&bounds, -1, -1);
    DrawFilledRoundRect(
        draw->hDC,
        bounds,
        Scale(8),
        fill,
        border,
        focused ? Scale(2) : Scale(1));

    SetBkMode(draw->hDC, TRANSPARENT);
    SetTextColor(draw->hDC, foreground);
    HFONT oldFont = static_cast<HFONT>(
        SelectObject(
            draw->hDC,
            id == IDC_START_BUTTON ? g_fontHeading : g_fontBody));
    DrawTextW(
        draw->hDC,
        text,
        -1,
        &bounds,
        DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    SelectObject(draw->hDC, oldFont);
}

void DrawOwnerCombo(const DRAWITEMSTRUCT* draw) {
    COLORREF background =
        (draw->itemState & ODS_SELECTED)
            ? kCrimsonDark
            : kPanelRaised;
    HBRUSH brush = CreateSolidBrush(background);
    FillRect(draw->hDC, &draw->rcItem, brush);
    DeleteObject(brush);

    if (draw->itemID == static_cast<UINT>(-1)) {
        return;
    }

    std::wstring text;
    try {
        const LRESULT length = SendMessageW(
            draw->hwndItem,
            CB_GETLBTEXTLEN,
            draw->itemID,
            0);
        if (length >= 0 && length <= 32767) {
            text.resize(static_cast<size_t>(length) + 1);
            const LRESULT copied = SendMessageW(
                draw->hwndItem,
                CB_GETLBTEXT,
                draw->itemID,
                reinterpret_cast<LPARAM>(text.data()));
            if (copied >= 0) {
                text.resize(static_cast<size_t>(copied));
            } else {
                text.clear();
            }
        }
    } catch (...) {
        text.clear();
    }

    RECT textRect = draw->rcItem;
    textRect.left += Scale(9);
    textRect.right -= Scale(5);
    SetBkMode(draw->hDC, TRANSPARENT);
    SetTextColor(
        draw->hDC,
        (draw->itemState & ODS_DISABLED) ? RGB(95, 95, 99) : kText);
    HFONT oldFont = static_cast<HFONT>(
        SelectObject(draw->hDC, g_fontSmall));
    DrawTextW(
        draw->hDC,
        text.empty() ? L"Голос Windows" : text.c_str(),
        -1,
        &textRect,
        DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    SelectObject(draw->hDC, oldFont);
}

bool CreateControls(HWND window) {
    CreateLabel(
        window,
        -1,
        L"ТЕКСТ ЛИТАНИИ",
        36,
        133,
        250,
        27,
        g_fontHeading);
    CreateLabel(
        window,
        -1,
        L"КОНТУР ПРЕОБРАЗОВАНИЯ ГОЛОСА",
        706,
        133,
        390,
        27,
        g_fontHeading);

    g_litanyEdit = CreateWindowExW(
        WS_EX_CLIENTEDGE,
        L"EDIT",
        L"О, Великий Омниссия, благослови дух этой машины.\r\n"
        L"Да будут чисты её цепи, стабильны частоты и безошибочны вычисления.\r\n"
        L"Пусть бинарный гимн прогонит скверну сбоя,\r\n"
        L"а священный перезапуск вернёт гармонию кремнию и стали.",
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL |
            ES_MULTILINE | ES_AUTOVSCROLL | ES_WANTRETURN,
        Scale(34),
        Scale(166),
        Scale(622),
        Scale(420),
        window,
        reinterpret_cast<HMENU>(
            static_cast<INT_PTR>(IDC_LITANY_EDIT)),
        g_instance,
        nullptr);
    SendMessageW(
        g_litanyEdit,
        EM_SETLIMITTEXT,
        static_cast<WPARAM>(kMaxEditorCharacters),
        0);
    SendMessageW(
        g_litanyEdit,
        EM_SETMARGINS,
        EC_LEFTMARGIN | EC_RIGHTMARGIN,
        MAKELPARAM(Scale(12), Scale(12)));
    SetControlFont(g_litanyEdit, g_fontBody);

    g_openButton = CreateOwnerButton(
        window,
        IDC_OPEN_BUTTON,
        L"ОТКРЫТЬ TXT",
        34,
        603,
        178,
        40);
    g_saveButton = CreateOwnerButton(
        window,
        IDC_SAVE_BUTTON,
        L"СОХРАНИТЬ TXT",
        222,
        603,
        188,
        40);
    g_counterLabel = CreateLabel(
        window,
        IDC_COUNTER_LABEL,
        L"",
        423,
        608,
        232,
        30,
        g_fontSmall,
        SS_RIGHT);

    CreateLabel(
        window,
        -1,
        L"Голосовой движок Windows",
        706,
        165,
        410,
        21,
        g_fontSmall);
    g_voiceCombo = CreateWindowExW(
        0,
        L"COMBOBOX",
        nullptr,
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL |
            CBS_DROPDOWNLIST | CBS_OWNERDRAWFIXED | CBS_HASSTRINGS,
        Scale(706),
        Scale(188),
        Scale(418),
        Scale(230),
        window,
        reinterpret_cast<HMENU>(
            static_cast<INT_PTR>(IDC_VOICE_COMBO)),
        g_instance,
        nullptr);
    SetControlFont(g_voiceCombo, g_fontSmall);

    CreateLabel(
        window,
        -1,
        L"Протокол обработки",
        706,
        226,
        410,
        21,
        g_fontSmall);
    g_presetCombo = CreateWindowExW(
        0,
        L"COMBOBOX",
        nullptr,
        WS_CHILD | WS_VISIBLE | WS_TABSTOP |
            CBS_DROPDOWNLIST | CBS_OWNERDRAWFIXED | CBS_HASSTRINGS,
        Scale(706),
        Scale(249),
        Scale(418),
        Scale(220),
        window,
        reinterpret_cast<HMENU>(
            static_cast<INT_PTR>(IDC_PRESET_COMBO)),
        g_instance,
        nullptr);
    SetControlFont(g_presetCombo, g_fontSmall);
    const std::array<const wchar_t*, 6> presets = {
        L"Пользовательский",
        L"Сбалансированный магос",
        L"Боевой вокс-кастер",
        L"Бинарный жрец",
        L"Архимагос",
        L"Чистый голос SAPI"};
    for (const wchar_t* preset : presets) {
        SendMessageW(
            g_presetCombo,
            CB_ADDSTRING,
            0,
            reinterpret_cast<LPARAM>(preset));
    }

    g_mechanicalCheck = CreateOwnerButton(
        window,
        IDC_MECHANICAL_CHECK,
        L"МЕХАНИЧЕСКИЙ ВОКС",
        706,
        286,
        210,
        27);
    g_binaryCheck = CreateOwnerButton(
        window,
        IDC_BINARY_CHECK,
        L"БИНАРНАЯ ТЕЛЕМЕТРИЯ",
        920,
        286,
        204,
        27);

    const int sliderStartY = 319;
    const int sliderStep = 31;
    for (size_t index = 0; index < kSliderBindings.size(); ++index) {
        const int y = sliderStartY + static_cast<int>(index) * sliderStep;
        CreateLabel(
            window,
            -1,
            kSliderBindings[index].label,
            706,
            y + 3,
            145,
            24,
            g_fontSmall);
        g_sliders[index] = CreateMagosSlider(
            window,
            kSliderBindings[index].sliderId,
            846,
            y,
            224,
            28,
            kSliderBindings[index].minimum,
            kSliderBindings[index].maximum,
            0);
        g_valueLabels[index] = CreateLabel(
            window,
            kSliderBindings[index].valueId,
            L"",
            1076,
            y + 3,
            48,
            24,
            g_fontMono,
            SS_RIGHT);
    }

    g_startButton = CreateOwnerButton(
        window,
        IDC_START_BUTTON,
        L"НАЧАТЬ ОБРЯД",
        20,
        690,
        262,
        44);
    g_stopButton = CreateOwnerButton(
        window,
        IDC_STOP_BUTTON,
        L"ПРЕРВАТЬ",
        294,
        690,
        168,
        44);
    g_testButton = CreateOwnerButton(
        window,
        IDC_TEST_BUTTON,
        L"ТЕСТ ВОКСА",
        474,
        690,
        196,
        44);
    EnableWindow(g_stopButton, FALSE);

    g_statusLabel = CreateLabel(
        window,
        IDC_STATUS_LABEL,
        L"КОНТУР ГОТОВ. ДУХ МАШИНЫ ОЖИДАЕТ ЛИТАНИЮ.",
        20,
        750,
        1120,
        22,
        g_fontMono);

    UpdateCharacterCounter();
    const bool slidersReady = std::all_of(
        g_sliders.begin(),
        g_sliders.end(),
        [](HWND control) { return control != nullptr; });
    const bool valuesReady = std::all_of(
        g_valueLabels.begin(),
        g_valueLabels.end(),
        [](HWND control) { return control != nullptr; });
    return g_litanyEdit && g_voiceCombo && g_presetCombo &&
           g_mechanicalCheck && g_binaryCheck &&
           g_openButton && g_saveButton &&
           g_startButton && g_stopButton && g_testButton &&
           g_counterLabel && g_statusLabel &&
           slidersReady && valuesReady;
}

void PopulateVoices() {
    g_voices = EnumerateSapiVoices();
    int defaultIndex = 0;
    if (g_voices.empty()) {
        VoiceInfo fallback;
        fallback.displayName = L"Системный голос Windows";
        fallback.isDefault = true;
        g_voices.push_back(std::move(fallback));
    }

    for (size_t index = 0; index < g_voices.size(); ++index) {
        SendMessageW(
            g_voiceCombo,
            CB_ADDSTRING,
            0,
            reinterpret_cast<LPARAM>(
                g_voices[index].displayName.c_str()));
        if (g_voices[index].isDefault) {
            defaultIndex = static_cast<int>(index);
        }
    }
    SendMessageW(g_voiceCombo, CB_SETCURSEL, defaultIndex, 0);
}

void DrawMainWindowSurface(HDC device, const RECT& client) {
    HBRUSH background = CreateSolidBrush(kBackground);
    FillRect(device, &client, background);
    DeleteObject(background);

    RECT header = {0, 0, client.right, Scale(104)};
    HBRUSH headerBrush = CreateSolidBrush(RGB(12, 13, 16));
    FillRect(device, &header, headerBrush);
    DeleteObject(headerBrush);
    RECT headerLine = {0, Scale(101), client.right, Scale(104)};
    HBRUSH lineBrush = CreateSolidBrush(kCrimson);
    FillRect(device, &headerLine, lineBrush);
    DeleteObject(lineBrush);

    DrawMechanicusEmblem(
        device,
        Scale(62),
        Scale(51),
        Scale(35));

    SetBkMode(device, TRANSPARENT);
    SetTextColor(device, kText);
    HFONT oldFont = static_cast<HFONT>(
        SelectObject(device, g_fontTitle));
    RECT titleRect = {
        Scale(112),
        Scale(19),
        Scale(690),
        Scale(58)};
    DrawTextW(
        device,
        L"КАРМАННЫЙ МАГОС",
        -1,
        &titleRect,
        DT_LEFT | DT_SINGLELINE | DT_VCENTER);
    SelectObject(device, g_fontSmall);
    SetTextColor(device, kCrimsonBright);
    RECT subtitleRect = {
        Scale(114),
        Scale(59),
        Scale(690),
        Scale(83)};
    DrawTextW(
        device,
        L"АДЕПТУС МЕХАНИКУС  //  ВОКС-ЛИТУРГИЯ IV",
        -1,
        &subtitleRect,
        DT_LEFT | DT_SINGLELINE | DT_VCENTER);
    SelectObject(device, oldFont);

    DrawBinaryHeader(device, client);

    RECT editorPanel = {
        Scale(20),
        Scale(118),
        Scale(670),
        Scale(664)};
    RECT settingsPanel = {
        Scale(690),
        Scale(118),
        Scale(1140),
        Scale(664)};
    DrawFilledRoundRect(
        device,
        editorPanel,
        Scale(12),
        kPanel,
        RGB(48, 48, 53));
    DrawFilledRoundRect(
        device,
        settingsPanel,
        Scale(12),
        kPanel,
        RGB(48, 48, 53));

    const int total = g_playbackLengthMs.load();
    const int current = g_playbackPositionMs.load();
    RECT progressTrack = {
        Scale(20),
        Scale(741),
        Scale(1140),
        Scale(746)};
    DrawFilledRoundRect(
        device,
        progressTrack,
        Scale(5),
        RGB(42, 42, 47),
        RGB(42, 42, 47));
    if (total > 0) {
        const double ratio =
            std::clamp(current / static_cast<double>(total), 0.0, 1.0);
        RECT progress = progressTrack;
        progress.right =
            progress.left +
            static_cast<int>(
                (progressTrack.right - progressTrack.left) * ratio);
        DrawFilledRoundRect(
            device,
            progress,
            Scale(5),
            kCrimsonBright,
            kCrimsonBright);

        const std::wstring clock =
            FormatClock(current) + L" / " + FormatClock(total);
        SelectObject(device, g_fontMono);
        SetTextColor(device, kMutedText);
        RECT clockRect = {
            Scale(940),
            Scale(713),
            Scale(1140),
            Scale(735)};
        DrawTextW(
            device,
            clock.c_str(),
            -1,
            &clockRect,
            DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
    } else {
        SelectObject(device, g_fontSmall);
        SetTextColor(device, kMutedText);
        RECT noteRect = {
            Scale(694),
            Scale(694),
            Scale(1140),
            Scale(734)};
        DrawTextW(
            device,
            L"Персональная фанатская утилита. Не связана с Games Workshop.",
            -1,
            &noteRect,
            DT_RIGHT | DT_BOTTOM | DT_WORDBREAK);
    }

}

void PaintMainWindow(HWND window) {
    PAINTSTRUCT paint = {};
    HDC screenDevice = BeginPaint(window, &paint);
    RECT client = {};
    GetClientRect(window, &client);
    const int width = std::max<LONG>(1, client.right - client.left);
    const int height = std::max<LONG>(1, client.bottom - client.top);

    if (g_mainBackBuffer.Ensure(screenDevice, width, height)) {
        DrawMainWindowSurface(g_mainBackBuffer.device, client);
        BitBlt(
            screenDevice,
            paint.rcPaint.left,
            paint.rcPaint.top,
            paint.rcPaint.right - paint.rcPaint.left,
            paint.rcPaint.bottom - paint.rcPaint.top,
            g_mainBackBuffer.device,
            paint.rcPaint.left,
            paint.rcPaint.top,
            SRCCOPY);
    } else {
        DrawMainWindowSurface(screenDevice, client);
    }
    EndPaint(window, &paint);
}

void FinishRitualIfReady(HWND window) {
    if (!g_workerCompleted.exchange(
            false,
            std::memory_order_acq_rel)) {
        return;
    }

    if (g_workerThread) {
        const DWORD waitResult =
            WaitForSingleObject(g_workerThread, 100);
        if (waitResult == WAIT_TIMEOUT) {
            g_workerCompleted.store(
                true,
                std::memory_order_release);
            return;
        }
        CloseHandle(g_workerThread);
        g_workerThread = nullptr;
    }
    g_running.store(false);
    RefreshControlAvailability();

    const HRESULT result =
        g_workerResult.load(std::memory_order_relaxed);
    if (result == HRESULT_FROM_WIN32(ERROR_CANCELLED)) {
        SetStatusText(L"РИТУАЛ ПРЕРВАН. ВОКС-КАНАЛ ЗАКРЫТ.");
    } else if (SUCCEEDED(result)) {
        SetStatusText(
            L"ЛИТАНИЯ ЗАВЕРШЕНА. ДУХ МАШИНЫ УМИРОТВОРЁН.");
    } else if (result == HRESULT_FROM_WIN32(ERROR_FILE_TOO_LARGE)) {
        SetStatusText(L"ЛИТАНИЯ ПРЕВЫСИЛА БЕЗОПАСНЫЙ ОБЪЁМ");
        MessageBoxW(
            window,
            L"После синтеза эта литания оказалась слишком длинной для "
            L"безопасной обработки в памяти.\r\n\r\n"
            L"Разделите её на несколько частей: настройки и выбранный голос "
            L"между обрядами сохранятся.",
            L"Литания слишком длинная",
            MB_OK | MB_ICONWARNING);
    } else if (result == E_OUTOFMEMORY) {
        SetStatusText(L"НЕДОСТАТОЧНО ПАМЯТИ ДЛЯ ОБРАБОТКИ ЛИТАНИИ");
        MessageBoxW(
            window,
            L"Windows не удалось выделить память для звукового контура. "
            L"Разделите литанию на несколько частей и повторите обряд.",
            L"Недостаточно памяти",
            MB_OK | MB_ICONERROR);
    } else {
        SetStatusText(L"СБОЙ ВОКС-КОНТУРА");
        const std::wstring error =
            L"Не удалось завершить литанию:\r\n\r\n" +
            DescribeError(result);
        MessageBoxW(
            window,
            error.c_str(),
            L"Ошибка голосового контура",
            MB_OK | MB_ICONERROR);
    }
    InvalidateRect(window, nullptr, FALSE);
    if (g_closeAfterStop) {
        DestroyWindow(window);
    }
}

void InvalidateDynamicRegions(HWND window) {
    RECT client = {};
    GetClientRect(window, &client);
    RECT header = {
        0,
        0,
        client.right,
        std::min<LONG>(client.bottom, Scale(105))};
    RECT playback = {
        0,
        std::min<LONG>(client.bottom, Scale(704)),
        client.right,
        std::min<LONG>(client.bottom, Scale(749))};
    InvalidateRect(window, &header, FALSE);
    InvalidateRect(window, &playback, FALSE);
}

LRESULT CALLBACK MainWindowProc(
    HWND window,
    UINT message,
    WPARAM wParam,
    LPARAM lParam) {
    switch (message) {
        case WM_CREATE: {
            g_mainWindow = window;
            BOOL darkMode = TRUE;
            DwmSetWindowAttribute(
                window,
                20,
                &darkMode,
                sizeof(darkMode));
            HICON icon = static_cast<HICON>(
                LoadImageW(
                    g_instance,
                    MAKEINTRESOURCEW(IDI_APP_ICON),
                    IMAGE_ICON,
                    0,
                    0,
                    LR_DEFAULTSIZE));
            if (icon) {
                SendMessageW(window, WM_SETICON, ICON_BIG, reinterpret_cast<LPARAM>(icon));
                SendMessageW(window, WM_SETICON, ICON_SMALL, reinterpret_cast<LPARAM>(icon));
            }
            if (!CreateControls(window)) {
                MessageBoxW(
                    window,
                    L"Windows не удалось создать один или несколько "
                    L"элементов интерфейса.",
                    L"Ошибка интерфейса",
                    MB_OK | MB_ICONERROR);
                return -1;
            }
            PopulateVoices();
            LoadSettings();
            RefreshControlAvailability();
            SetTimer(
                window,
                kAnimationTimerId,
                kAnimationPeriodMs,
                nullptr);
            return 0;
        }
        case WM_ERASEBKGND:
            return 1;
        case WM_PAINT:
            PaintMainWindow(window);
            return 0;
        case WM_SIZE:
            g_mainBackBuffer.Reset();
            InvalidateRect(window, nullptr, FALSE);
            return 0;
        case WM_TIMER:
            if (wParam != kAnimationTimerId) {
                break;
            }
            FinishRitualIfReady(window);
            if (IsWindow(window) && !IsIconic(window)) {
                g_logoAngle = std::fmod(
                    g_logoAngle +
                        (g_running.load() ? 0.026 : 0.006),
                    2.0 * 3.14159265358979323846);
                g_binaryAnimation ^= g_binaryAnimation << 13;
                g_binaryAnimation ^= g_binaryAnimation >> 17;
                g_binaryAnimation ^= g_binaryAnimation << 5;
                InvalidateDynamicRegions(window);
            }
            return 0;
        case WM_MEASUREITEM: {
            auto* measure = reinterpret_cast<MEASUREITEMSTRUCT*>(lParam);
            if (measure->CtlType == ODT_COMBOBOX) {
                measure->itemHeight = Scale(28);
                return TRUE;
            }
            break;
        }
        case WM_DRAWITEM: {
            const auto* draw =
                reinterpret_cast<DRAWITEMSTRUCT*>(lParam);
            if (draw->CtlType == ODT_BUTTON) {
                DrawOwnerButton(draw);
                return TRUE;
            }
            if (draw->CtlType == ODT_COMBOBOX) {
                DrawOwnerCombo(draw);
                return TRUE;
            }
            break;
        }
        case WM_CTLCOLORSTATIC: {
            HDC device = reinterpret_cast<HDC>(wParam);
            SetBkMode(device, TRANSPARENT);
            HWND control = reinterpret_cast<HWND>(lParam);
            const int id = GetDlgCtrlID(control);
            if (id == IDC_STATUS_LABEL) {
                SetTextColor(
                    device,
                    g_running.load() ? kBinaryGreen : kMutedText);
                SetBkColor(device, kBackground);
                return reinterpret_cast<LRESULT>(g_backgroundBrush);
            }
            if (!IsWindowEnabled(control)) {
                SetTextColor(device, RGB(96, 96, 100));
            } else {
                SetTextColor(device, kText);
            }
            SetBkColor(device, kPanel);
            return reinterpret_cast<LRESULT>(g_staticPanelBrush);
        }
        case WM_CTLCOLOREDIT: {
            HDC device = reinterpret_cast<HDC>(wParam);
            SetTextColor(device, kText);
            SetBkColor(device, RGB(13, 14, 16));
            return reinterpret_cast<LRESULT>(g_editBrush);
        }
        case WM_CTLCOLORLISTBOX: {
            HDC device = reinterpret_cast<HDC>(wParam);
            SetTextColor(device, kText);
            SetBkColor(device, kPanelRaised);
            return reinterpret_cast<LRESULT>(g_panelRaisedBrush);
        }
        case WM_HSCROLL: {
            HWND slider = reinterpret_cast<HWND>(lParam);
            if (slider) {
                const int id = GetDlgCtrlID(slider);
                for (size_t index = 0;
                     index < kSliderBindings.size();
                     ++index) {
                    if (kSliderBindings[index].sliderId == id) {
                        UpdateSliderValueLabel(index);
                        MarkSettingsCustom();
                        break;
                    }
                }
            }
            return 0;
        }
        case WM_COMMAND: {
            const int id = LOWORD(wParam);
            const int notification = HIWORD(wParam);
            switch (id) {
                case IDC_LITANY_EDIT:
                    if (notification == EN_CHANGE) {
                        UpdateCharacterCounter();
                    }
                    return 0;
                case IDC_PRESET_COMBO:
                    if (notification == CBN_SELCHANGE) {
                        ApplyPreset(
                            static_cast<int>(
                                SendMessageW(
                                    g_presetCombo,
                                    CB_GETCURSEL,
                                    0,
                                    0)));
                    }
                    return 0;
                case IDC_VOICE_COMBO:
                    return 0;
                case IDC_MECHANICAL_CHECK:
                case IDC_BINARY_CHECK:
                    if (notification == BN_CLICKED) {
                        HWND checkbox = reinterpret_cast<HWND>(lParam);
                        if (id == IDC_MECHANICAL_CHECK) {
                            g_mechanicalEnabled = !g_mechanicalEnabled;
                        } else {
                            g_binaryEnabled = !g_binaryEnabled;
                        }
                        MarkSettingsCustom();
                        RefreshControlAvailability();
                        InvalidateRect(checkbox, nullptr, FALSE);
                    }
                    return 0;
                case IDC_OPEN_BUTTON:
                    if (!g_running.load()) {
                        OpenLitany();
                    } else {
                        MessageBeep(MB_ICONWARNING);
                    }
                    return 0;
                case IDC_SAVE_BUTTON:
                    SaveLitany();
                    return 0;
                case IDC_START_BUTTON:
                    BeginRitual();
                    return 0;
                case IDC_STOP_BUTTON:
                    StopRitual();
                    return 0;
                case IDC_TEST_BUTTON: {
                    const std::wstring test =
                        L"Слышьте глас Омниссии. Ноль — это тишина. "
                        L"Единица — это воля Машины. Вокс-контур освящён.";
                    BeginRitual(&test);
                    return 0;
                }
            }
            break;
        }
        case WM_MAGOS_STATUS: {
            if (g_running.load()) {
                switch (static_cast<RitualStage>(wParam)) {
                    case RitualStage::Synthesizing:
                        SetStatusText(L"СИНТЕЗ ГЛАСА МАШИНЫ...");
                        break;
                    case RitualStage::VoiceFallback:
                        SetStatusText(
                            L"ВЫБРАННЫЙ ГОЛОС НЕДОСТУПЕН. "
                            L"ИСПОЛЬЗУЕТСЯ СИСТЕМНЫЙ.");
                        break;
                    case RitualStage::Processing:
                        SetStatusText(
                            L"НАЛОЖЕНИЕ ТЕМБРА, ВОКС-ИСКАЖЕНИЙ "
                            L"И БИНАРНЫХ ПЕЧАТЕЙ...");
                        break;
                    case RitualStage::Playing:
                        SetStatusText(
                            L"ЛИТУРГИЧЕСКАЯ ПЕРЕДАЧА АКТИВНА");
                        break;
                }
            }
            return 0;
        }
        case WM_MAGOS_FINISHED:
            FinishRitualIfReady(window);
            return 0;
        case WM_CLOSE:
            if (g_running.load()) {
                const int answer = MessageBoxW(
                    window,
                    L"Литания ещё звучит. Прервать ритуал и закрыть приложение?",
                    L"Активный вокс-канал",
                    MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2);
                if (answer == IDYES) {
                    g_closeAfterStop = true;
                    StopRitual();
                }
                return 0;
            }
            DestroyWindow(window);
            return 0;
        case WM_DESTROY:
            SaveSettings();
            KillTimer(window, kAnimationTimerId);
            g_stopRequested.store(true);
            if (g_workerThread) {
                WaitForSingleObject(g_workerThread, 500);
                CloseHandle(g_workerThread);
                g_workerThread = nullptr;
            }
            g_mainBackBuffer.Reset();
            g_mainWindow = nullptr;
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(window, message, wParam, lParam);
}

bool RegisterWindowClasses() {
    WNDCLASSEXW sliderClass = {};
    sliderClass.cbSize = sizeof(sliderClass);
    sliderClass.hInstance = g_instance;
    sliderClass.lpfnWndProc = SliderWindowProc;
    sliderClass.lpszClassName = kSliderWindowClass;
    sliderClass.hCursor = LoadCursorW(nullptr, IDC_HAND);
    sliderClass.hbrBackground =
        reinterpret_cast<HBRUSH>(GetStockObject(NULL_BRUSH));
    if (!RegisterClassExW(&sliderClass)) {
        return false;
    }

    WNDCLASSEXW mainClass = {};
    mainClass.cbSize = sizeof(mainClass);
    mainClass.hInstance = g_instance;
    mainClass.lpfnWndProc = MainWindowProc;
    mainClass.lpszClassName = kMainWindowClass;
    mainClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    mainClass.hIcon = LoadIconW(
        g_instance,
        MAKEINTRESOURCEW(IDI_APP_ICON));
    mainClass.hIconSm = mainClass.hIcon;
    mainClass.hbrBackground = g_backgroundBrush;
    return RegisterClassExW(&mainClass) != 0;
}

}  // namespace

int WINAPI wWinMain(
    HINSTANCE instance,
    HINSTANCE,
    PWSTR,
    int showCommand) {
    g_instance = instance;

    SetProcessDpiAwarenessContext(
        DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    RECT workArea = {};
    if (!SystemParametersInfoW(
            SPI_GETWORKAREA,
            0,
            &workArea,
            0)) {
        workArea = {
            0,
            0,
            GetSystemMetrics(SM_CXSCREEN),
            GetSystemMetrics(SM_CYSCREEN)};
    }
    const DWORD style =
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU |
        WS_MINIMIZEBOX | WS_CLIPCHILDREN;
    const DWORD extendedStyle = WS_EX_APPWINDOW;
    const UINT requestedDpi = GetDpiForSystem();
    g_dpi = ChooseLayoutDpi(
        workArea,
        requestedDpi,
        style,
        extendedStyle);

    INITCOMMONCONTROLSEX controls = {};
    controls.dwSize = sizeof(controls);
    controls.dwICC = ICC_STANDARD_CLASSES;
    InitCommonControlsEx(&controls);

    const HRESULT comResult =
        CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    const bool comInitialized =
        comResult == S_OK || comResult == S_FALSE;

    g_fontBody = CreateInterfaceFont(10, FW_NORMAL, L"Segoe UI");
    g_fontSmall = CreateInterfaceFont(9, FW_NORMAL, L"Segoe UI");
    g_fontHeading = CreateInterfaceFont(10, FW_SEMIBOLD, L"Bahnschrift");
    g_fontTitle = CreateInterfaceFont(20, FW_BOLD, L"Bahnschrift");
    g_fontMono = CreateInterfaceFont(9, FW_NORMAL, L"Consolas");
    g_editBrush = CreateSolidBrush(RGB(13, 14, 16));
    g_backgroundBrush = CreateSolidBrush(kBackground);
    g_staticPanelBrush = CreateSolidBrush(kPanel);
    g_panelRaisedBrush = CreateSolidBrush(kPanelRaised);

    if (!RegisterWindowClasses()) {
        MessageBoxW(
            nullptr,
            L"Не удалось зарегистрировать интерфейс Карманного Магоса.",
            L"Критическая ошибка",
            MB_OK | MB_ICONERROR);
        return 1;
    }

    RECT windowBounds = CalculateWindowBounds(
        g_dpi,
        requestedDpi,
        style,
        extendedStyle);
    const int windowWidth =
        windowBounds.right - windowBounds.left;
    const int windowHeight =
        windowBounds.bottom - windowBounds.top;
    const int workWidth = workArea.right - workArea.left;
    const int workHeight = workArea.bottom - workArea.top;

    HWND window = CreateWindowExW(
        extendedStyle,
        kMainWindowClass,
        L"Карманный Магос 4 — Вокс-литургия Адептус Механикус",
        style,
        workArea.left + std::max(0, (workWidth - windowWidth) / 2),
        workArea.top + std::max(0, (workHeight - windowHeight) / 2),
        windowWidth,
        windowHeight,
        nullptr,
        nullptr,
        instance,
        nullptr);
    if (!window) {
        MessageBoxW(
            nullptr,
            DescribeError(HRESULT_FROM_WIN32(GetLastError())).c_str(),
            L"Не удалось открыть Карманного Магоса",
            MB_OK | MB_ICONERROR);
        return 2;
    }

    ShowWindow(window, showCommand);
    UpdateWindow(window);

    ACCEL accelerators[] = {
        {FVIRTKEY, VK_F5, IDC_START_BUTTON},
        {FVIRTKEY, VK_ESCAPE, IDC_STOP_BUTTON},
        {static_cast<BYTE>(FVIRTKEY | FCONTROL), 'O', IDC_OPEN_BUTTON},
        {static_cast<BYTE>(FVIRTKEY | FCONTROL), 'S', IDC_SAVE_BUTTON},
    };
    HACCEL acceleratorTable = CreateAcceleratorTableW(
        accelerators,
        static_cast<int>(std::size(accelerators)));

    MSG message = {};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        if (!TranslateAcceleratorW(
                window,
                acceleratorTable,
                &message)) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
    }

    if (acceleratorTable) {
        DestroyAcceleratorTable(acceleratorTable);
    }
    DeleteObject(g_panelRaisedBrush);
    DeleteObject(g_staticPanelBrush);
    DeleteObject(g_backgroundBrush);
    DeleteObject(g_editBrush);
    DeleteObject(g_fontMono);
    DeleteObject(g_fontTitle);
    DeleteObject(g_fontHeading);
    DeleteObject(g_fontSmall);
    DeleteObject(g_fontBody);
    if (comInitialized) {
        CoUninitialize();
    }
    return static_cast<int>(message.wParam);
}
